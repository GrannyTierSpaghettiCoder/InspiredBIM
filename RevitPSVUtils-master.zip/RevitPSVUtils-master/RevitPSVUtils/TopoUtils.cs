﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class TopoUtils
    {
        public static XYZ GetProjectBasePointCoordinate(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var siteCategoryfilter = new ElementCategoryFilter(BuiltInCategory.OST_ProjectBasePoint);

            var collector = new FilteredElementCollector(doc);
            var siteElements = collector.WherePasses(siteCategoryfilter).ToElements();

            XYZ projectBasePoint = null;

            foreach (Element ele in siteElements)
            {
                var paramX = ele.get_Parameter(BuiltInParameter.BASEPOINT_EASTWEST_PARAM);
                double X = paramX.AsDouble();

                var paramY = ele.get_Parameter(BuiltInParameter.BASEPOINT_NORTHSOUTH_PARAM);
                double Y = paramY.AsDouble();

                var paramElev = ele.get_Parameter(BuiltInParameter.BASEPOINT_ELEVATION_PARAM);
                double Elev = paramElev.AsDouble();

                projectBasePoint = new XYZ(X, Y, Elev);
            }

            return projectBasePoint;
        }

        public static XYZ ConvertPointRelativeToSurveyPosition(ExternalCommandData commandData, XYZ pointToConvert)
        {
            if (pointToConvert == null)
                return null;
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var pl = doc.ActiveProjectLocation;
            var ttr = pl.GetTotalTransform().Inverse;
            var surveyPosition = doc.ActiveProjectLocation.GetProjectPosition(new XYZ(0, 0, 0));
            XYZ point = ttr.OfPoint(pointToConvert);
            return point;
        }
    }
}
