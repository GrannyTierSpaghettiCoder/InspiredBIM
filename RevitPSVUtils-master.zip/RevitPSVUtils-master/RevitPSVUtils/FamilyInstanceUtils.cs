﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class FamilyInstanceUtils
    {

        public static void PopulateFamilyIntancesWithParameterValues(List<FamilyInstance> fInstanceList,
            string parameterName, string parameterValue)
        {
            foreach (var fInstance in fInstanceList)
            {
                ElementUtils.SetElementParameterValue(fInstance, parameterName, parameterValue);
            }
        }

        public static List<FamilyInstance> GetAllTheFamilyInstancesOfType(
            ExternalCommandData commandData,
            string familyTypeName)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;

            //get target family
            List<FamilyInstance> fInstances = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Where(e => e.Name.Equals(familyTypeName))
                .Cast<FamilyInstance>()
                .ToList();
            return fInstances;

        }

        public static List<FamilyInstance> GetMEPFamilyInstances(ExternalCommandData commandData)
        {
            return GenericSelectionUtils<FamilyInstance>
                    .GetObjectsByType(commandData)
                    .Where(f => f.IsMEPFamilyInstance())
                    .ToList();
        }



        public static List<FamilyInstance> GetAllTheFamilyInstancesOfBuiltinCategory(
            ExternalCommandData commandData,
            BuiltInCategory category)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;

            //get target family
            List<FamilyInstance> fInstances = new FilteredElementCollector(doc)
                .OfCategory(category)
                .Cast<FamilyInstance>()
                .ToList();
            return fInstances;

        }

        public static List<FamilyInstance> GetAllTheFamilyInstancesOfBuiltinCategory(
            ExternalCommandData commandData,
            BuiltInCategory category,
            View oView)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;

            //get target family
            List<FamilyInstance> fInstances = new FilteredElementCollector(doc, oView.Id)
                .OfCategory(category)
                .Cast<FamilyInstance>()
                .ToList();
            return fInstances;

        }

        public static void GetAllTheMonitoringFamilyInstances(
            ExternalCommandData commandData,
            ref List<FamilyInstance> familyInstances,
            ref List<Element> systemFamilyInstances)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            //get target family
            familyInstances = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Where(e => e.IsMonitoringLinkElement())
                .Cast<FamilyInstance>()
                .ToList();
            systemFamilyInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .ToElements()
                .Where(e => e.IsMonitoringLinkElement())
                .ToList();
        }



        public static List<FamilyInstance> GetAllTheFamilyInstancesOfFamily(
            ExternalCommandData commandData,
            string familyName)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;

            //get target family
            List<FamilyInstance> fInstances = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Cast<FamilyInstance>()
                .Where(f => f.Symbol.FamilyName.Equals(familyName))
                .ToList();
            return fInstances;

        }
        public static void DeleteFamilyInstances(
            ExternalCommandData commandData,
            List<FamilyInstance> instances)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Delete family instances"))
            {
                t.Start();
                foreach (var instance in instances)
                {
                    doc.Delete(instance.Id);
                }
                t.Commit();
            }
        }

        public static FamilyInstance CreateFamilyInstanceOnHostElement(
            ExternalCommandData commandData,
            Element oElement,
            XYZ insertionPoint,
            string familyName,
            string familyTypeName)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            FamilyInstance familyInstance = null;

            Level oLevel = doc.GetElement(oElement.LevelId) as Level;
            //get target family
            Family f = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .FirstOrDefault(q => q.Name.Contains(familyName))
                as Family;
            //get its types
            var fIds = f.GetFamilySymbolIds();
            FamilySymbol familyType = null;
            //get target type
            foreach (Autodesk.Revit.DB.ElementId id in f.GetFamilySymbolIds())
            {
                familyType = f.Document.GetElement(id) as Autodesk.Revit.DB.FamilySymbol;
                if (familyType.Name.Contains(familyTypeName))
                {
                    break;
                }
            }
            if (familyType == null)
            {
                return null;
            }
            //create family instance
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                if (!familyType.IsActive)
                {
                    familyType.Activate();
                    doc.Regenerate();
                }
                familyInstance = doc.Create.NewFamilyInstance(insertionPoint,
                familyType,
                oElement,
                oLevel,
                Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                t.Commit();
            }
            return familyInstance;
        }



        public static FamilyInstance CreateFamilyInstance(
            ExternalCommandData commandData,
            FamilySymbol oFamSymb,
            XYZ insertionPoint,
            Level oLevel)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            FamilyInstance familyInstance = null;
            //create family instance
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                if (!oFamSymb.IsActive)
                {
                    oFamSymb.Activate();
                    doc.Regenerate();
                }
                familyInstance = doc.Create.NewFamilyInstance(
                insertionPoint,
                oFamSymb,
                oLevel,
                Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                t.Commit();
            }
            return familyInstance;
        }


        public static FamilyInstance CreateFamilyInstance(
            FamilySymbol oFamSymb,
            XYZ insertionPoint,
            Level oLevel)
        {
            if (oFamSymb == null)
                return null;
            FamilyInstance familyInstance = null;
            var doc = oFamSymb.Document;
            //create family instance
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                if (!oFamSymb.IsActive)
                {
                    oFamSymb.Activate();
                    doc.Regenerate();
                }
                familyInstance = doc.Create.NewFamilyInstance(
                insertionPoint,
                oFamSymb,
                oLevel,
                Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                t.Commit();
            }
            return familyInstance;
        }

        public static FamilyInstance CreateFamilyInstance(ExternalCommandData commandData, FamilySymbol oFamSymb, XYZ insertionPoint)
        {
            Document doc = commandData.Application.ActiveUIDocument.Document;
            FamilyInstance familyInstance = (FamilyInstance)null;
            using (Transaction transaction = new Transaction(doc, "Create family instance"))
            {
                transaction.Start();
                if (!oFamSymb.IsActive)
                {
                    oFamSymb.Activate();
                    doc.Regenerate();
                }
                familyInstance = familyInstance = doc.Create.NewFamilyInstance(
                insertionPoint,
                oFamSymb,
                StructuralType.NonStructural);
                transaction.Commit();
            }
            return familyInstance;
        }

        public static FamilyInstance CreateFamilyInstance(
            ExternalCommandData commandData,
            FamilySymbol oFamSymb,
            XYZ insertionPoint,
            View oView)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            FamilyInstance familyInstance = null;
            //create family instance
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                if (!oFamSymb.IsActive)
                {
                    oFamSymb.Activate();
                    doc.Regenerate();
                }
                familyInstance = doc.Create.NewFamilyInstance(
                insertionPoint,
                oFamSymb,
                oView);
                t.Commit();
            }
            return familyInstance;
        }

        /// <summary>
        /// Doesn't Work!!!
        /// </summary>
        /// <param name="commandData"></param>
        /// <param name="oFamSymb"></param>
        /// <param name="insertionPoint"></param>
        /// <param name="oLevel"></param>
        /// <param name="anglePlan"></param>
        /// <returns></returns>
        public static FamilyInstance CreateFamilyInstanceAndRotate(
            ExternalCommandData commandData,
            FamilySymbol oFamSymb,
            XYZ insertionPoint,
            Level oLevel,
            double anglePlan)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            FamilyInstance familyInstance = null;
            //create family instance
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                if (!oFamSymb.IsActive)
                {
                    oFamSymb.Activate();
                    doc.Regenerate();
                }
                familyInstance = doc.Create.NewFamilyInstance(
                insertionPoint,
                oFamSymb,
                oLevel,
                Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                //var familyLocation = familyInstance.Location as LocationPoint;
                //var rotBaseStartPoint = familyLocation.Point;
                //var rotBaseEndPoint = new XYZ(rotBaseStartPoint.X, rotBaseStartPoint.Y, rotBaseStartPoint.Z + 10);
                var axis = Line.CreateBound(new XYZ(0, 0, 0), new XYZ(0, 0, 1));
                ElementTransformUtils.RotateElement(doc, familyInstance.Id, axis, anglePlan);
                //familyLocation.Rotate(axis, anglePlan);
                t.Commit();
            }
            return familyInstance;
        }


        public static void CreateAdaptiveFamilyInstance(ExternalCommandData commandData, FamilySymbol symbol, List<XYZ> insertionPoints)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create adaptive family instance"))
            {
                t.Start();
                // Create a new instance of an adaptive component family
                FamilyInstance instance = AdaptiveComponentInstanceUtils.CreateAdaptiveComponentInstance(doc, symbol);

                // Get the placement points of this instance
                var placePointIds = AdaptiveComponentInstanceUtils.GetInstancePlacementPointElementRefIds(instance);
                // Set the position of each placement point
                for (int i = 0; i < placePointIds.Count; i++)
                {
                    var point = doc.GetElement(placePointIds[i]) as ReferencePoint;
                    if (i >= insertionPoints.Count)
                    {
                        break;
                    }
                    point.Position = insertionPoints[i];
                }
                t.Commit();
            }
        }

        public static List<FamilyInstance> AddNestedFamiliesToExistedFamiliesList(ExternalCommandData commandData,
                                                            List<FamilyInstance> familyInstancesList)
        {

            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var nestedFamilyInstances = new List<FamilyInstance>();

            foreach (var fInstance in familyInstancesList)
            {
                if (fInstance is FamilyInstance)
                {
                    var aFamilyInst = fInstance as FamilyInstance;
                    if (aFamilyInst == null)
                        continue;

                    // we need to skip nested family instances 
                    // since we already get them as per below
                    if (aFamilyInst.SuperComponent == null)
                    {
                        // this is a family that is a root family
                        // ie might have nested families 
                        // but is not a nested one
                        var subElements = aFamilyInst.GetSubComponentIds();
                        if (subElements.Count == 0)
                            continue;
                        else
                        {
                            // has nested families
                            foreach (var aSubElemId in subElements)
                            {
                                var aSubElem = doc.GetElement(aSubElemId);
                                if (aSubElem is FamilyInstance)
                                {
                                    var subFamInstance = aSubElem as FamilyInstance;
                                    nestedFamilyInstances.Add(subFamInstance);
                                }
                            }
                        }
                    }
                }
            }

            familyInstancesList.AddRange(nestedFamilyInstances);
            return familyInstancesList;
        }
    }
}
