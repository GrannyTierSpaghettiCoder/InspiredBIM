﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class NumberUtils
    {
        public static double FindNearestValue(List<double> values, double targetNumber)
        {
            var nearest = values.OrderBy(value => Math.Abs(value - targetNumber)).First();
            return nearest;
        }

        public static double MillimetersToFeet(double value)
        {
            return value * 0.00328084;
        }

        public static double MillimetersToFeet(double value, int accuracy)
        {
            return Math.Round(value * 0.00328084, accuracy);
        }

        public static double MillimetersToFeet(string value, int accuracy)
        {
            var parsedDouble = ParseStringToDouble(value);
            return MillimetersToFeet(parsedDouble, accuracy);
        }

        public static double FeetToMillimeters(double value)
        {
            return value * 304.8;
        }

        public static double FeetToMeters(double value)
        {
            return value * 304.8 / 1000;
        }

        public static double ParseStringToDouble(string stringToParse)
        {
            double value = 0;
            stringToParse = stringToParse.Replace(',', '.');
            if (double.TryParse(stringToParse, NumberStyles.Any, CultureInfo.InvariantCulture, out value))
            {
                return value;
            }
            else
            {
                return 0;
            }
        }

        public static double ParseStringToDouble(string stringToParse, int accuracy)
        {
            double value = 0;
            stringToParse = stringToParse.Replace(',', '.');
            if (double.TryParse(stringToParse, NumberStyles.Any, CultureInfo.InvariantCulture, out value))
            {
                return Math.Round(value, 6);
            }
            else
            {
                return 0;
            }
        }

        public static List<double> ParseStringToDoubleList(List<string> stringsToParse)
        {
            var parsedNumbers = stringsToParse.Select(s => ParseStringToDouble(s)).ToList();
            return parsedNumbers;
        }

        public static int ParseStringToInt(string stringToParse)
        {
            int value = 0;
            stringToParse = stringToParse.Replace(',', '.');
            if (int.TryParse(stringToParse, NumberStyles.Any, CultureInfo.InvariantCulture, out value))
            {
                return value;
            }
            else
            {
                return 0;
            }
        }

        public static bool IsInRange(double value, double min, double max)
        {
            return value >= min && value <= max;
        }

        public static double DegreesToRadians(double degrees)
        {
            return (Math.PI / 180) * degrees;
        }
    }
}
