﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class IntersectionUtils
    {
        public static XYZ FindPipeAndWallIntersectionPoint(Pipe oPipe, Wall oWall)
        {
            var oPipeCurve = oPipe.GetPipeCurve();
            var oWallFaces = oWall.GetWallFaces();
            XYZ intersectionResult = null;
            foreach (var oWallFace in oWallFaces)
            {
                //The intersection point
                IntersectionResultArray intersectionR = new IntersectionResultArray();//Intersection point set

                SetComparisonResult results;//Results of Comparison

                results = oWallFace.Intersect(oPipeCurve, out intersectionR);

                if (SetComparisonResult.Disjoint != results)
                {
                    if (intersectionR != null)
                    {
                        if (!intersectionR.IsEmpty)
                        {
                            intersectionResult = intersectionR.get_Item(0).XYZPoint;
                            break;
                        }
                    }
                }
            }
            return intersectionResult;
        }

        public static PipeAndFloorIntersections FindPipeAndFloorIntersection(
            ExternalCommandData commandData, Pipe oPipe, Floor oFloor)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            XYZ intersectionResult = null;

            var options = new Options();
            options.ComputeReferences = true;
            options.IncludeNonVisibleObjects = false;

            var oPipeCurve = oPipe.GetPipeCurve();
            var oFloorElement = oFloor.get_Geometry(options);
            var oFloorSolids = new List<Solid>();
            AddSolids(oFloorElement, ref oFloorSolids);
            var facesFromFloorSolids = new List<Face>();
            FacesFromSolids(oFloorSolids, facesFromFloorSolids);
            foreach (var oFloorFace in facesFromFloorSolids)
            {
                //The intersection point
                IntersectionResultArray intersectionR = new IntersectionResultArray();//Intersection point set

                SetComparisonResult results;//Results of Comparison

                results = oFloorFace.Intersect(oPipeCurve, out intersectionR);

                if (SetComparisonResult.Disjoint != results
                    && intersectionR != null
                    && !intersectionR.IsEmpty)
                {

                    intersectionResult = intersectionR.get_Item(0).XYZPoint;
                    return new PipeAndFloorIntersections
                    {
                        oPipe = oPipe,
                        oIntersectedFloor = oFloor,
                        intersectPoints = new List<XYZ>()
                                {
                                    intersectionResult
                                }
                    };
                }
            }
            //Element floorElement = doc.GetElement(oFloor.Id) as Element;
            //var view3d = doc.ActiveView as View3D;
            //if (view3d == null)
            //{
            //    TaskDialog.Show("Ошибка", "Включи 3D вид");
            //}
            //var floorBox = floorElement.get_BoundingBox(view3d);
            //var floorBoxOutline = new Outline(floorBox.Min, floorBox.Max);
            //var floorBoxInterFilter = new BoundingBoxIntersectsFilter(floorBoxOutline);
            //var oPipesIn3dView = new FilteredElementCollector(doc)
            //    .OfClass(typeof(FamilyInstance))
            //    .OfCategory(BuiltInCategory.OST_PipeSegments)
            //    .WherePasses(floorBoxInterFilter)
            //    .ToList();
            //if (oPipesIn3dView.Count > 0)
            //{
            //    return true;
            //}
            //else
            //{
            //    return false;
            //}
            return null;
        }

        public static List<PipeAndFloorIntersections> FindPipeAndFloorIntersections(
            ExternalCommandData commandData, List<Pipe> oPipes, List<Floor> oFloors)
        {
            var pairs = new List<PipeAndFloorIntersections>();
            foreach (var oPipe in oPipes)
            {
                foreach (var oFloor in oFloors)
                {
                    var pair = FindPipeAndFloorIntersection(commandData, oPipe, oFloor);
                    pairs.Add(pair);
                }
            }
            return pairs;
        }

        public static double ComputeIntersectionVolume(Solid solidA, Solid solidB)
        {
            //double volumeOfIntersection = 0.0;
            double surfaceAreaOfIntersection = 0.0;
            Solid intersection = BooleanOperationsUtils.ExecuteBooleanOperation(solidA, solidB, BooleanOperationsType.Intersect);
            if (intersection != null)
                surfaceAreaOfIntersection = intersection.SurfaceArea;
            return surfaceAreaOfIntersection;
        }

        private static void AddCurvesAndSolids(Autodesk.Revit.DB.GeometryElement geomElem,
                                ref Autodesk.Revit.DB.CurveArray curves,
                                ref System.Collections.Generic.List<Autodesk.Revit.DB.Solid> solids)
        {
            foreach (Autodesk.Revit.DB.GeometryObject geomObj in geomElem)
            {

                Autodesk.Revit.DB.Curve curve = geomObj as Autodesk.Revit.DB.Curve;
                if (null != curve)
                {

                    curves.Append(curve);
                    continue;
                }
                Autodesk.Revit.DB.Solid solid = geomObj as Autodesk.Revit.DB.Solid;
                if (null != solid && solid.Volume != 0 && solid.Visibility == Visibility.Visible && !solid.Edges.IsEmpty)
                {

                    solids.Add(solid);
                    continue;
                }
                //If this GeometryObject is Instance, call AddCurvesAndSolids
                Autodesk.Revit.DB.GeometryInstance geomInst = geomObj as Autodesk.Revit.DB.GeometryInstance;
                if (null != geomInst)
                {
                    Autodesk.Revit.DB.GeometryElement transformedGeomElem
                      = geomInst.GetInstanceGeometry(geomInst.Transform);
                    AddCurvesAndSolids(transformedGeomElem, ref curves, ref solids);
                }
            }
        }

        private static void AddSolids(Autodesk.Revit.DB.GeometryElement geomElem,
                                ref System.Collections.Generic.List<Autodesk.Revit.DB.Solid> solids)
        {
            foreach (Autodesk.Revit.DB.GeometryObject geomObj in geomElem)
            {

                Autodesk.Revit.DB.Solid solid = geomObj as Autodesk.Revit.DB.Solid;
                if (null != solid && solid.Volume != 0 && solid.Visibility == Visibility.Visible && !solid.Edges.IsEmpty)
                {

                    solids.Add(solid);
                    continue;
                }
                //If this GeometryObject is Instance, call AddCurvesAndSolids
                Autodesk.Revit.DB.GeometryInstance geomInst = geomObj as Autodesk.Revit.DB.GeometryInstance;
                if (null != geomInst)
                {
                    Autodesk.Revit.DB.GeometryElement transformedGeomElem
                      = geomInst.GetInstanceGeometry(geomInst.Transform);
                    AddSolids(transformedGeomElem, ref solids);
                }
            }
        }

        private static void FacesFromSolids(List<Solid> solidsA, List<Face> facesOfA)
        {
            foreach (Solid A in solidsA)
            {
                foreach (Face fa in A.Faces)
                {
                    ElementId mid = fa.MaterialElementId;
                    if (mid == null)
                    {
                        continue;
                    }

                    facesOfA.Add(fa);
                }
            }
        }
    }
}
