﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class LocationUtils
    {
        public static ProjectLocation SetProjectLocation(Document document,
                                                            double angleDegrees,
                                                            XYZ point)
        {
            ProjectLocation currentLocation = null;
            using (var t = new Autodesk.Revit.DB.Transaction(document, "Create family instance"))
            {
                t.Start();
                currentLocation = document.ActiveProjectLocation;


                //get the project position
                XYZ origin = XYZ.Zero;

                ProjectPosition projectPosition = currentLocation.GetProjectPosition(origin);

                //Angle from True North
                double angle = NumberUtils.DegreesToRadians(angleDegrees);   // convert degrees to radian

                //create a new project position
                ProjectPosition newPosition =
                  document.Application.Create.NewProjectPosition(point.X, point.Y, point.Z, angle);

                if (null != newPosition)
                {
                    //set the value of the project position
                    currentLocation.SetProjectPosition(origin, newPosition);
                }
                t.Commit();
            }
            return currentLocation;
        }


        public static ProjectLocation GetProjectLocation(Document document)
        {
            var currentLocation = document.ActiveProjectLocation;
            //get the project position
            XYZ origin = XYZ.Zero;
            ProjectPosition projectPosition = currentLocation.GetProjectPosition(origin);
            return currentLocation;
        }

        public static XYZ GetProjectLocationXYZ(Document document)
        {
            var point = GetProjectLocation(document).GetXYZPosition();
            return point;
        }
    }
}
