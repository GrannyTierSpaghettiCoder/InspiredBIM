﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class ProjectLocationExts
    {
        public static XYZ GetXYZPosition(this ProjectLocation projectLocation)
        {
            var projPos = projectLocation.GetProjectPosition(XYZ.Zero);
            return new XYZ(projPos.EastWest, projPos.NorthSouth, projPos.Elevation);
        }
    }
}
