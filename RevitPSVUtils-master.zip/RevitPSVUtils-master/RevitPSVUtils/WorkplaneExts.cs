﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class WorkplaneExts
    {
        //public static XYZ ProjectOnto(
        //             this Plane plane,
        //             XYZ p)
        //{
        //    double d = plane.SignedDistanceTo(p);
        //    XYZ q = p - d * plane.Normal;
        //    return q;
        //}
        //public static double SignedDistanceTo(
        //     this Plane plane,
        //        XYZ p)
        //{
        //    XYZ v = p - plane.Origin;
        //    return plane.Normal.DotProduct(v);
        //}

        

        
    }
}
