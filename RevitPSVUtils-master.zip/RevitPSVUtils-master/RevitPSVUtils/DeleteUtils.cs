﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class DeleteUtils
    {
        public static void DeleteElements(ExternalCommandData commandData, List<Element> elements)
        {
            Document doc = commandData.Application.ActiveUIDocument.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create adaptive family instance"))
            {
                t.Start();
                foreach (Element elem in elements)
                {
                    doc.Delete(elem.Id);
                }
                t.Commit();
            }
        }
        public static void DeleteElements(Document doc, List<Element> elements)
        {
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create adaptive family instance"))
            {
                t.Start();
                foreach (Element elem in elements)
                {
                    doc.Delete(elem.Id);
                }
                t.Commit();
            }
        }
    }
}
