﻿using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class RibbonUtils
    {
        public void CreateTab(UIControlledApplication app, string tabName)
        {
            app.CreateRibbonTab(tabName);
        }
        public RibbonPanel AddPanel(UIControlledApplication app, string tabNameToAdd, string panelName)
        {
            return app.CreateRibbonPanel(tabNameToAdd, panelName);
        }
        
    }
}
