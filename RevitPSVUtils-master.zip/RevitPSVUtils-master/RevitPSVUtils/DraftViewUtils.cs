﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class DraftViewUtils
    {
        public static ViewDrafting CreateDraftView(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var vd = new FilteredElementCollector(doc)
            .OfClass(typeof(ViewFamilyType))
                .Cast<ViewFamilyType>()
            .FirstOrDefault(q => q.ViewFamily == ViewFamily.Drafting);

            var draftView = ViewDrafting.Create(doc, vd.Id);
            return draftView;
        }
    }
}
