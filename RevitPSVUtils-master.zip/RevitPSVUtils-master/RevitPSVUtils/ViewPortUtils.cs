﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class ViewPortUtils
    {
        public static Viewport CreateAndPlaceInCenterOfSheet(ViewSheet viewSheet, View view, 
                                                                ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var sheetBox = viewSheet.Outline;
            double yPosition = (sheetBox.Max.V - sheetBox.Min.V) / 2 + sheetBox.Min.V;
            double xPosition = (sheetBox.Max.U - sheetBox.Min.U) / 2 + sheetBox.Min.U;

            XYZ planViewPortInsertPoint = new XYZ(xPosition, yPosition, 0);

            var viewPort = Viewport.Create(doc, viewSheet.Id, view.Id, planViewPortInsertPoint);
            return viewPort;
        }
    }
}
