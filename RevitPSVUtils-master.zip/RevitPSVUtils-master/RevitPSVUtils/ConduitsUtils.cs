﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class ConduitsUtils
    {
        public static Conduit CreateNewConduitByTypeOfExisted(
                            Conduit existedConduit, XYZ startPoint, XYZ endPoint, ExternalCommandData commandData)
        {

            if (startPoint.IsEqualByXYZ(endPoint))
                return null;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            if (!Conduit.IsValidLevelId(doc, existedConduit.ReferenceLevel.Id))
            {
                return null;
            }

            if (!Conduit.IsValidConduitType(doc, existedConduit.GetTypeId()))
            {
                return null;
            }

            Conduit oConduit = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                oConduit = Conduit.Create(doc, existedConduit.GetTypeId(), startPoint, endPoint, 
                                            existedConduit.ReferenceLevel.Id);
                existedConduit.CopyParametersValueTo(oConduit);

                t.Commit();
            }
            return oConduit;
        }
    }
}
