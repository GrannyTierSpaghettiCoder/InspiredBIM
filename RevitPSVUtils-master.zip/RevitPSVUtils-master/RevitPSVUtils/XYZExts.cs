﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace RevitPSVUtils
{
    public static class XYZExts
    {
        public static XYZ Round(this XYZ point, int accuracy)
        {
            return new XYZ(
                Math.Round(point.X, accuracy),
                Math.Round(point.Y, accuracy),
                Math.Round(point.Z, accuracy));
        }

        public static XYZ MovePoint(this XYZ point, XYZ direction, double length)
        {
            direction = direction / direction.GetLength();
            XYZ movedPoint = point + length * direction;
            return movedPoint;
        }

        public static bool IsEqualByXY(this XYZ point1, XYZ point2)
        {
            if (point1.X == point2.X && point1.Y == point2.Y)
                return true;
            return false;
        }

        public static bool IsEqualByXYZ(this XYZ point1, XYZ point2)
        {
            if (point1.X == point2.X && point1.Y == point2.Y && point1.Z == point2.Z)
                return true;
            return false;
        }

        public static bool IsEqualByXYZ(this XYZ point1, XYZ point2, int accuracy)
        {
            if (Math.Round(point1.X, accuracy) == Math.Round(point2.X, accuracy) &&
                Math.Round(point1.Y, accuracy) == Math.Round(point2.Y, accuracy) &&
                Math.Round(point1.Z, accuracy) == Math.Round(point2.Z, accuracy))
                return true;
            return false;
        }

        public static bool IsDirectionNegative(this XYZ direction)
        {
            if (direction.X < 0 || direction.Y < 0 || direction.Z < 0)
                return false;
            return true;
        }
        public static bool IsDirectionPositive(this XYZ direction)
        {
            if (direction.X > 0 || direction.Y > 0 || direction.Z > 0)
                return false;
            return true;
        }

        public static bool InsideMinAndMaxXYZPoints(this XYZ pointToCheck, XYZ minPoint, XYZ maxPoint)
        {
            bool isPointInsideX = (pointToCheck.X >= minPoint.X) && (pointToCheck.X <= maxPoint.X);
            bool isPointInsideY = (pointToCheck.Y >= minPoint.Y) && (pointToCheck.Y <= maxPoint.Y);
            bool isPointInsideZ = (pointToCheck.Z >= minPoint.Z) && (pointToCheck.Z <= maxPoint.Z);
            if (isPointInsideX && isPointInsideY && isPointInsideZ)
            {
                return true;
            }
            return false;
        }

        public static bool IsPointBetweenOtherPoints(this XYZ point, XYZ startPoint, XYZ endPoint, int accuracy)
        {
            var distanceBetweenStartEndPoint = startPoint.DistanceTo(endPoint);
            var distanceStartAndThisPoint = startPoint.DistanceTo(point);
            var distanceEndAndThisPoint = endPoint.DistanceTo(point);
            var distanceThisPointAndStartEnd = distanceStartAndThisPoint + distanceEndAndThisPoint;

            if (Math.Round(distanceBetweenStartEndPoint, accuracy) == Math.Round(distanceThisPointAndStartEnd, accuracy))
                return true;
            return false;
        }

        public static XYZ CopyPointWithYOffset(this XYZ point, double yOffset)
        {
            return new XYZ(point.X, point.Y + yOffset, point.Z);
        }

        public static XYZ MillimetersToFeet(this XYZ point)
        {
            return new XYZ(NumberUtils.MillimetersToFeet(point.X),
                            NumberUtils.MillimetersToFeet(point.Y),
                            NumberUtils.MillimetersToFeet(point.Z));
        }

        public static XYZ FeetToMillimeters(this XYZ point)
        {
            return new XYZ(NumberUtils.FeetToMillimeters(point.X),
                            NumberUtils.FeetToMillimeters(point.Y),
                            NumberUtils.FeetToMillimeters(point.Z));
        }
    }
}
