﻿using Autodesk.Revit.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using RevitPSVUtils.EnumData;

namespace RevitPSVUtils
{
    public class PointUtils
    {
        public static XYZ PickAPoint(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            XYZ userPoint = null;
            userPoint = uidoc.Selection.PickPoint(
            "Выбери точку");
            return userPoint;
        }

        

        public static XYZ PickPointOnCurrentWorkplane(
            ExternalCommandData commandData)
        {
            var doc = commandData.Application.ActiveUIDocument.Document;

            var t = new Transaction(doc,
                "Set Work Plane");
            t.Start();
            var plane = Plane.CreateByNormalAndOrigin(doc.ActiveView.ViewDirection, doc.ActiveView.Origin);
            var sp = SketchPlane.Create(doc, plane);

            doc.ActiveView.SketchPlane = sp;
            doc.ActiveView.ShowActiveWorkPlane();

            t.Commit();
            return PickAPoint(commandData);
        }

        public static List<XYZ> PickPointsOnCurrentWorkplane(
            ExternalCommandData commandData, WorkPlaneShow wpShow, int pointsCount)
        {
            var doc = commandData.Application.ActiveUIDocument.Document;
            var t = new Transaction(doc,
                "Get points on current workplane");
            t.Start();
            //берем рабочую плоскости, которая стандартна для текущего вида
            var plane = Plane.CreateByNormalAndOrigin(doc.ActiveView.ViewDirection, doc.ActiveView.Origin);
            //создаём плоскости отрисовки
            var sp = SketchPlane.Create(doc, plane);
            //и делаем её активной
            doc.ActiveView.SketchPlane = sp;
            //если нужно - включаем её отображаение
            if (wpShow == WorkPlaneShow.On)
                doc.ActiveView.ShowActiveWorkPlane();
            t.Commit();
            //и берем точки от юзера
            var points = new List<XYZ>();
            for (int i = 0; i < pointsCount; i++)
            {
                points.Add(PickAPoint(commandData));
            }
            return points;
        }
    }
}
