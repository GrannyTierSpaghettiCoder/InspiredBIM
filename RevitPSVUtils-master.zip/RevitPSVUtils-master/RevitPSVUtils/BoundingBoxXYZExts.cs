﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class BoundingBoxXYZExts
    {
        public static void GetEdgePointsOfBoundigBox(
            this BoundingBoxXYZ boundBox,
            ref XYZ leftBottomPoint,
            ref XYZ leftTopPoint,
            ref XYZ rightTopPoint,
            ref XYZ rightBottomPoint)
        {
            //высчитываем крайние точки
            leftBottomPoint = boundBox.Min;
            leftTopPoint = new XYZ(
                boundBox.Min.X,
                boundBox.Max.Y,
                boundBox.Max.Z);
            rightTopPoint = boundBox.Max;
            rightBottomPoint = new XYZ(
                boundBox.Max.X,
                boundBox.Min.Y,
                boundBox.Min.Z);
        }

        public static void GetEdgePointsOfBoundigBoxByXZ(
            this BoundingBoxXYZ boundBox,
            ref XYZ leftBottomPoint,
            ref XYZ leftTopPoint,
            ref XYZ rightTopPoint,
            ref XYZ rightBottomPoint)
        {
            //высчитываем крайние точки
            leftBottomPoint = boundBox.Min;
            leftTopPoint = new XYZ(
                boundBox.Min.X,
                boundBox.Max.Y,
                boundBox.Max.Z);
            rightTopPoint = boundBox.Max;
            rightBottomPoint = new XYZ(
                boundBox.Max.X,
                boundBox.Max.Y,
                boundBox.Min.Z);
        }
        public static void GetEdgePointsOfBoundigBoxByYZ(
            this BoundingBoxXYZ boundBox,
            ref XYZ leftBottomPoint,
            ref XYZ leftTopPoint,
            ref XYZ rightTopPoint,
            ref XYZ rightBottomPoint)
        {
            //высчитываем крайние точки
            leftBottomPoint = boundBox.Min;
            leftTopPoint = new XYZ(
                boundBox.Max.X,
                boundBox.Min.Y,
                boundBox.Max.Z);
            rightTopPoint = boundBox.Max;
            rightBottomPoint = new XYZ(
                boundBox.Max.X,
                boundBox.Max.Y,
                boundBox.Min.Z);
        }

        public static double GetXWidth(this BoundingBoxXYZ boundBox)
        {
            var minPoint = boundBox.Min;
            var maxPoint = boundBox.Max;
            var xWidth = boundBox.Max.X - boundBox.Min.X;
            return xWidth;
        }

        public static double GetYHeight(this BoundingBoxXYZ boundBox)
        {
            var minPoint = boundBox.Min;
            var maxPoint = boundBox.Max;
            var yHeight = boundBox.Max.Y - boundBox.Min.Y;
            return yHeight;
        }

        public static BoundingBoxXYZ Rotate(
      this BoundingBoxXYZ boundBox,
      Transform transform)
        {
            double height = boundBox.Max.Z - boundBox.Min.Z;

            // Four corners: lower left, lower right, 
            // upper right, upper left:

            XYZ[] corners = Util.GetBottomCorners(boundBox);

            XyzComparable[] cornersTransformed
              = corners.Select<XYZ, XyzComparable>(
                p => new XyzComparable(transform.OfPoint(p)))
                  .ToArray();

            boundBox.Min = cornersTransformed.Min();
            boundBox.Max = cornersTransformed.Max();
            boundBox.Max += height * XYZ.BasisZ;

            return boundBox;
        }

        public static bool IsInsideBoundingBox(
            this BoundingBoxXYZ smallBoundBox,
            BoundingBoxXYZ bigBoundBox)
        {
            //проверяем входит точки маленького бокса внутрь большого
            var isMinPointInsideBigBox = smallBoundBox.Min
                                            .InsideMinAndMaxXYZPoints(bigBoundBox.Min, bigBoundBox.Max);
            var isMaxPointInsideBigBox = smallBoundBox.Max
                                            .InsideMinAndMaxXYZPoints(bigBoundBox.Min, bigBoundBox.Max);
            if (isMinPointInsideBigBox && isMaxPointInsideBigBox)
                return true;
            else
                return false;
        }

        public static XYZ MiddlePointXYZ(this BoundingBoxXYZ bbox)
        {
            return (bbox.Max + bbox.Min) / 2;
        }
    }
}
