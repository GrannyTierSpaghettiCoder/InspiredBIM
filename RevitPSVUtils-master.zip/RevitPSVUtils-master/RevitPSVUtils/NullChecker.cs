﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class NullChecker
    {
        public List<object> ObjectsToCheck { get; set; }

        /// <summary>
        /// Проверяет объекты на null. Если найден объект с null, то возвращается true.
        /// </summary>
        /// <param name="objectsToCheck">Объекты для проверки на null</param>
        /// <returns></returns>
        public bool CheckObjectsForNull(List<object> objectsToCheck)
        {
            foreach (var objToCheck in objectsToCheck)
            {
                if (objToCheck == null)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
