﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class RoomUtils
    {
        public static List<Room> GetRooms(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var rooms = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .Cast<Room>()
                .ToList();

            return rooms;
        }

        public static List<Room> GetRooms(ExternalCommandData commandData, string parameterName, string parameterValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var rooms = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .Cast<Room>()
                .ToList();

            var resultRooms = new List<Room>();

            foreach (var room in rooms)
            {
                var returnedValue = room.GetParameterValueToString(parameterName);
                if (returnedValue.Contains(parameterValue))
                    resultRooms.Add(room);
            }
            return resultRooms;
        }

        public static List<FamilySymbol> GetRoomTagTypes(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var roomTags = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(f => f.Category.Id.IntegerValue == (int)BuiltInCategory.OST_RoomTags)
                .ToList();

            return roomTags;
        }

        public static XYZ GetRoomCenter(Room room)
        {
            // Get the room center point.
            XYZ boundCenter = room.GetElementCenter();
            LocationPoint locPt = (LocationPoint)room.Location;
            XYZ roomCenter = new XYZ(boundCenter.X, boundCenter.Y, locPt.Point.Z);
            return roomCenter;
        }

        public static RoomTag CreateRoomTag(ExternalCommandData commandData, Room room, ViewPlan viewPlan)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            return doc.Create.NewRoomTag(new LinkElementId(room.Id), room.GetCenterPointUV(), viewPlan.Id);
        }

        public static RoomTag CreateRoomTag(ExternalCommandData commandData, Room room, ViewPlan viewPlan,
            RoomTagType roomTagType)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            var roomTag = doc.Create.NewRoomTag(new LinkElementId(room.Id), room.GetCenterPointUV(), viewPlan.Id);
            roomTag.RoomTagType = roomTagType;
            return roomTag;
        }
    }
}
