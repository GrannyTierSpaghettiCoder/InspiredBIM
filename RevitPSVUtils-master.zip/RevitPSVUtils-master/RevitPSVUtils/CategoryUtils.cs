﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class CategoryUtils
    {
        public static List<Category> GetAllTheCategories(ExternalCommandData commandData)
        {
            Document doc = commandData.Application.ActiveUIDocument.Document;
            var categoriesList = new List<Category>();
            Categories categories = doc.Settings.Categories;
            foreach (Category category in categories)
            {
                categoriesList.Add(category);
            }
            return categoriesList.OrderBy(c => c.Name).ToList();
        }
    }
}
