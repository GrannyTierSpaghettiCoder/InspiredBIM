﻿using Autodesk.Revit.DB;
using MathNet.Spatial.Euclidean;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils.Helpers
{
    public class MathNetHelper
    {
        public static Point3D FromXYZToPoint3D(XYZ point)
        {
            return new Point3D(point.X, point.Y, point.Z);
        }

        public static XYZ FromPoint3DToXYZ(Point3D point)
        {
            return new XYZ(point.X, point.Y, point.Z);
        }

        public static UnitVector3D FromXYZToUnitVector3D(XYZ direction)
        {
            return new UnitVector3D(direction.X, direction.Y, direction.Z);
        }
    }
}
