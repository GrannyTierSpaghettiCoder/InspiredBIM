﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class IntersectorUtils
    {
        //public static bool IsElementInsideFaces(Element oElement, Element elementToIntersect)
        //{
        //    FilteredElementCollector collector = new FilteredElementCollector(oElement.Document);
        //    Func<View3D, bool> isNotTemplate = v3 => !(v3.IsTemplate);
        //    View3D view3d = collector.OfClass(typeof(View3D)).Cast<View3D>().First(isNotTemplate);

        //    //var view3d = ViewUtils.Get3dView(oElement.Document);
        //    var elementMidPoint = oElement.GetMiddlePoint(view3d);

        //    ReferenceIntersector refIntersector = new ReferenceIntersector(
        //        new ElementClassFilter(typeof(FamilyInstance)),
        //        FindReferenceTarget.Face, view3d);

        //    var refIntByPositiveX = refIntersector.Find(elementMidPoint, XYZ.BasisX);
        //    var refIntByPositiveX1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisX);
        //    //if (refIntByPositiveX == null)
        //    //    return false;
        //    //if (refIntByPositiveX.GetReference().GlobalPoint == null)
        //    //    return false;
        //    var refIntByPositiveY = refIntersector.Find(elementMidPoint, XYZ.BasisY);
        //    var refIntByPositiveY1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisY);
        //    //if(refIntByPositiveY == null)
        //    //    return false;
        //    //if (refIntByPositiveY.GetReference().GlobalPoint == null)
        //    //    return false;
        //    var refIntByPositiveZ = refIntersector.Find(elementMidPoint, XYZ.BasisZ);
        //    var refIntByPositiveZ1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisZ);
        //    //if (refIntByPositiveZ == null)
        //    //    return false;
        //    //if (refIntByPositiveZ.GetReference().GlobalPoint == null)
        //    //    return false;

        //    var refIntByNegativeX = refIntersector.Find(elementMidPoint, XYZ.BasisX.Negate());
        //    var refIntByNegativeX1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisX.Negate());
        //    //if (refIntByNegativeX == null)
        //    //    return false;
        //    //if (refIntByNegativeX.GetReference().GlobalPoint == null)
        //    //    return false;

        //    var refIntByNegativeY = refIntersector.Find(elementMidPoint, XYZ.BasisY.Negate());
        //    var refIntByNegativeY1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisY.Negate());
        //    //if (refIntByNegativeY == null)
        //    //    return false;
        //    //if (refIntByNegativeY.GetReference().GlobalPoint == null)
        //    //    return false;

        //    var refIntByNegativeZ = refIntersector.Find(elementMidPoint, XYZ.BasisZ.Negate());
        //    var refIntByNegativeZ1 = refIntersector.FindNearest(elementMidPoint, XYZ.BasisZ.Negate());
        //    //if (refIntByNegativeZ == null)
        //    //    return false;
        //    //if (refIntByNegativeZ.GetReference().GlobalPoint == null)
        //    //    return false;

        //    return true;
        //}
    }
}
