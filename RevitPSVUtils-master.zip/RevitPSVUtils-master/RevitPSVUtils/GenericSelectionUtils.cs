﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class GenericSelectionUtils<T>
    {
        public static List<T> GetObjectsByType(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var elementClassFilter = new ElementClassFilter(typeof(T));

            var fInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .WherePasses(elementClassFilter)
                .Cast<T>()
                .ToList();
            return fInstances;
        }

        public static List<T> GetObjectsByType(Document doc)
        {
            var elementClassFilter = new ElementClassFilter(typeof(T));

            var fInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .WherePasses(elementClassFilter)
                .Cast<T>()
                .ToList();
            return fInstances;
        }

        public static List<T> GetObjectsWithWithElementTypes(Document doc)
        {
            var elementClassFilter = new ElementClassFilter(typeof(T));

            var fInstances = new FilteredElementCollector(doc)
                .WherePasses(elementClassFilter)
                .Cast<T>()
                .ToList();
            return fInstances;
        }
    }
}
