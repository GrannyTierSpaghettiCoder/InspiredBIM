﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TextFilesDealer;

namespace RevitPSVUtils
{
    public class FamilyUtils
    {
        /// <summary>
        /// Загрузка семейств из списка путей к файлам rfa
        /// </summary>
        /// <param name="filePaths">Списки путей к файлам .rfa</param>
        /// <param name="commandData"></param>
        public static void LoadFamiliesFromFilePaths(List<string> filePaths, ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Transaction(doc, "Load families"))
            {
                t.Start();
                foreach (var filePath in filePaths)
                {
                    bool isFilePathMatchFamilyExtension = filePath.Contains(".rfa");
                    if (!File.Exists(filePath) && !isFilePathMatchFamilyExtension)
                        continue;
                    doc.LoadFamily(filePath);
                }
                t.Commit();
            }
        }

        public static List<Family> GetFamiliesCurrentlyInModel(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;

            //get target family
            var families = new FilteredElementCollector(doc)
                 .OfClass(typeof(FamilyInstance))
                 .Cast<FamilyInstance>()
                 .Select(f => f.Symbol.Family)
                 .ToList();
            return families;
        }

        public static void LoadFamiliesFromFilePaths(List<string> filePaths, bool isOverwriteExistingFamily,
            ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var docDirectory = Path.GetDirectoryName(doc.PathName);

            var oTextData = new TextData(Path.Combine(docDirectory, "familiesLoadReport.txt"));
            oTextData.WriteTextToFile(WriteTypeEnum.Overwrite, new List<string> { "Не удалось загрузить семейства" });

            var familyOption = new FamilyOption();

            using (var t = new Transaction(doc, "Load families"))
            {
                t.Start();
                foreach (var filePath in filePaths)
                {
                    bool isFilePathMatchFamilyExtension = filePath.Contains(".rfa");
                    if (!File.Exists(filePath) && !isFilePathMatchFamilyExtension)
                        continue;
                    Family family = null;
                    if (isOverwriteExistingFamily)
                    {
                        if (!doc.LoadFamily(filePath, familyOption, out family))
                        {
                            oTextData.WriteTextToFile(WriteTypeEnum.Append, new List<string> { filePath });
                        }
                    }
                    else
                    {
                        if (!doc.LoadFamily(filePath))
                        {
                            oTextData.WriteTextToFile(WriteTypeEnum.Append, new List<string> { filePath });
                        }
                    }
                }
                t.Commit();
            }
        }

        public static List<Family> GetFamiliesOfCategory(
            ExternalCommandData commandData,
            Category category)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            List<Family> families;
            using (var t = new Transaction(doc, "Get family types"))
            {
                t.Start();
                //get target family
                families = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .Cast<Family>()
                .Where(f =>
                {
                    foreach (var symbolId in f.GetFamilySymbolIds())
                    {
                        var famSymbol = doc.GetElement(symbolId);
                        if (famSymbol.Category.Id.Equals(category.Id))
                        {
                            return true;
                        }
                    }
                    return false;
                })
                .ToList();
                t.Commit();
            }
            return families;
        }
        public static List<FamilySymbol> GetTypesOfFamily(ExternalCommandData commandData, Family oFamily)
        {
            var familySymbols = new List<FamilySymbol>();
            var famSymbolIds = oFamily.GetFamilySymbolIds();
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Get family types"))
            {
                t.Start();
                foreach (var famSymbolId in famSymbolIds)
                {
                    var familySymbol = doc.GetElement(famSymbolId) as FamilySymbol;
                    familySymbols.Add(familySymbol);
                }
                t.Commit();
            }
            return familySymbols;
        }

        public static List<FamilySymbol> GetFamilySymbolsOfCategory(ExternalCommandData commandData, BuiltInCategory category)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var familySymbols = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .OfCategory(category)
                .Cast<FamilySymbol>()
                .ToList();

            return familySymbols;
        }

        public static void GetFamilyAndItsSymbolByNames(
            ExternalCommandData commandData,
            string familyName,
            string familySymbolName,
            ref Family oFamily,
            ref FamilySymbol oFamilySymbol)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            //find the family with the name
            oFamily = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .FirstOrDefault(q => q.Name.Contains(familyName))
                as Family;
            //get its types
            if (oFamily != null)
            {
                var fIds = oFamily.GetFamilySymbolIds();
            }

            //get target symbol/type
            if (oFamily == null) return;
            foreach (var id in oFamily.GetFamilySymbolIds())
            {
                var familyType = oFamily.Document.GetElement(id) as FamilySymbol;
                if (familyType != null && familyType.Name.Contains(familySymbolName))
                {
                    oFamilySymbol = familyType;
                    break;
                }
            }
        }

        public static void GetFamilyAndItsSymbolByNames(
            Document doc,
            string familyName,
            string familySymbolName,
            ref Family oFamily,
            ref FamilySymbol oFamilySymbol)
        {
            //find the family with the name
            oFamily = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .FirstOrDefault(q => q.Name.Contains(familyName))
                as Family;
            //get its types
            if (oFamily != null)
            {
                var fIds = oFamily.GetFamilySymbolIds();
            }

            //get target symbol/type
            if (oFamily == null) return;
            foreach (var id in oFamily.GetFamilySymbolIds())
            {
                var familyType = oFamily.Document.GetElement(id) as FamilySymbol;
                if (familyType != null && familyType.Name.Contains(familySymbolName))
                {
                    oFamilySymbol = familyType;
                    break;
                }
            }
        }

        public static List<Family> GetFamilies(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var oFamilyList = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .Cast<Family>()
                .ToList();

            return oFamilyList;
        }

        public static void GetFamilyAndItsSymbolByNames(
            ExternalCommandData commandData,
            string familyName,
            string familySymbolName,
            ref FamilySymbol oFamilySymbol)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            //find the family with the name
            var oFamily = new FilteredElementCollector(doc)
                .OfClass(typeof(Family))
                .FirstOrDefault(q => q.Name.Contains(familyName))
                as Family;
            if (oFamily == null)
            {
                return;
            }
            //get its types
            var fIds = oFamily.GetFamilySymbolIds();
            //get target symbol/type
            foreach (var id in oFamily.GetFamilySymbolIds())
            {
                oFamilySymbol = oFamily.Document.GetElement(id) as FamilySymbol;
                if (oFamilySymbol != null && oFamilySymbol.Name.Contains(familySymbolName))
                {
                    break;
                }
            }
        }

        public static bool LoadFamilyFromFilePath(
           ExternalCommandData commandData, string filePath)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            Family family = null;

            doc.LoadFamily(filePath, new FamilyOption(), out family);

            if (family == null)
                return false;
            else
                return true;
        }
    }
}
