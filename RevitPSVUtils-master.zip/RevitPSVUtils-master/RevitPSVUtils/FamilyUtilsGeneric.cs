﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace RevitPSVUtils
{
    public class FamilyUtilsGeneric<T>
    {
        public static List<T> GetSystemFamilyTypes(Document doc, Type oType)
        {
            return new FilteredElementCollector(doc)
                .OfClass(oType)
                .Cast<T>()
                .ToList();
        }
    }
}
