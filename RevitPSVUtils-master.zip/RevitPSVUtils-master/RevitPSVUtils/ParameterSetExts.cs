﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace RevitPSVUtils
{
    public static class ParameterSetExts
    {
        public static Parameter GetParameterByName(this ParameterSet paramSet, string name)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    return parameter;
            }
            return null;
        }

        public static void SetParameterByName(this ParameterSet paramSet, string name, string value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }

        public static void SetParameterByName(this ParameterSet paramSet, string name, double value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }
        public static void SetParameterByName(this ParameterSet paramSet, string name, int value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }
    }
}
