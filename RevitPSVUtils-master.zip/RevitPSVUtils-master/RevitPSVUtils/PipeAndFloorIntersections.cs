﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class PipeAndFloorIntersections
    {
        public Pipe oPipe { get; set; }
        public Floor oIntersectedFloor { get; set; }
        public List<XYZ> intersectPoints { get; set; }

    }
}
