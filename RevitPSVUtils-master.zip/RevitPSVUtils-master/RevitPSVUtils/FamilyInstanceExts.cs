﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class FamilyInstanceExts
    {
        public static void SetParameterToFamilyInstance(
            this FamilyInstance oFamInstance,
            ExternalCommandData commandData,
            string parameterName,
            double value)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                oFamInstance.LookupParameter(parameterName).Set(value);
                t.Commit();
            }
        }


        public static void SetParameterToFamilyInstance(
            this FamilyInstance oFamInstance,
            string parameterName,
            double value)
        {
            using (var t = new Autodesk.Revit.DB.Transaction(oFamInstance.Document, "Create family instance"))
            {
                t.Start();
                oFamInstance.LookupParameter(parameterName).Set(value);
                t.Commit();
            }
        }

        public static List<XYZ> GetConnectorPoints(this FamilyInstance fInstance)
        {
            if (fInstance == null || fInstance.MEPModel.ConnectorManager == null)
                return null;
            ConnectorSetIterator connectorSetIterator = fInstance.MEPModel.ConnectorManager.Connectors.ForwardIterator();
            List<XYZ> xyzList = new List<XYZ>();
            while (connectorSetIterator.MoveNext())
            {
                Connector current = connectorSetIterator.Current as Connector;
                xyzList.Add(current.Origin);
            }
            return xyzList;
        }

        public static bool IsMEPFamilyInstance(this FamilyInstance fInstance)
        {
            return fInstance != null && fInstance.MEPModel.ConnectorManager != null;
        }

        public static void SetParameterToFamilyInstance(
            this FamilyInstance oFamInstance,
            ExternalCommandData commandData,
            string parameterName,
            string value)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create family instance"))
            {
                t.Start();
                oFamInstance.LookupParameter(parameterName).Set(value);
                t.Commit();
            }
        }

        public static XYZ GetLocation(this FamilyInstance famInst)
        {
            return ((LocationPoint)famInst?.Location)?.Point;
        }
        public static void RotateInPlan(this FamilyInstance famInst, ExternalCommandData commandData, double angleRad)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Autodesk.Revit.DB.Document doc = uidoc.Document;
            var location = famInst.GetLocation();
            var familyLocation = famInst.Location as LocationPoint;
            var rotBaseStartPoint = familyLocation.Point;
            var rotBaseEndPoint = new XYZ(rotBaseStartPoint.X, rotBaseStartPoint.Y, rotBaseStartPoint.Z + 10);
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Rotate family instance"))
            {
                t.Start();
                var axis = Line.CreateBound(rotBaseStartPoint, rotBaseEndPoint);
                ElementTransformUtils.RotateElement(doc, famInst.Id, axis, angleRad);
                t.Commit();
            }
            //familyLocation.Rotate(axis, anglePlan);
        }

        public static void RotateInPlan(this FamilyInstance famInst, double angleRad)
        {
            var location = famInst.GetLocation();
            var familyLocation = famInst.Location as LocationPoint;
            var rotBaseStartPoint = familyLocation.Point;
            var rotBaseEndPoint = new XYZ(rotBaseStartPoint.X, rotBaseStartPoint.Y, rotBaseStartPoint.Z + 10);
            using (var t = new Autodesk.Revit.DB.Transaction(famInst.Document, "Rotate family instance"))
            {
                t.Start();
                var axis = Line.CreateBound(rotBaseStartPoint, rotBaseEndPoint);
                ElementTransformUtils.RotateElement(famInst.Document, famInst.Id, axis, angleRad);
                t.Commit();
            }
            //familyLocation.Rotate(axis, anglePlan);
        }

        public static List<Connector> GetConnectors(this FamilyInstance fInstance)
        {
            if (fInstance == null)
                return null;
            if (fInstance.MEPModel.ConnectorManager == null)
                return null;

            var csi = fInstance.MEPModel.ConnectorManager.Connectors.ForwardIterator();
            var connectors = new List<Connector>();

            while (csi.MoveNext())
            {
                var connector = csi.Current as Connector;
                connectors.Add(connector);
            }

            return connectors;
        }


    }
}
