﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class WorksetUtils
    {
        public static string GetWorksetName(Element oElement, ExternalCommandData commandData)
        {
            if (oElement == null)
                return string.Empty;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;


            using (var t = new Transaction(doc, "Get ws name"))
            {
                t.Start();
                var worksetTable = doc.GetWorksetTable();
                var worksetIdByElement = doc.GetWorksetId(oElement.Id);
                var worksetByElement = worksetTable.GetWorkset(worksetIdByElement);
                return worksetByElement.Name;
            }
        }

        public static string GetWorksetName(Element oElement, WorksetTable worksetTable,
                                            ExternalCommandData commandData)
        {
            if (oElement == null)
                return string.Empty;

            var worksetIdByElement = oElement.Document.GetWorksetId(oElement.Id);
            var worksetByElement = worksetTable.GetWorkset(worksetIdByElement);
            return worksetByElement.Name;
        }

        public static string GetWorksetName(ElementId oElementId, WorksetTable worksetTable,
                                           ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            if (oElementId == null)
                return string.Empty;

            var oElement = doc.GetElement(oElementId);

            var worksetIdByElement = oElement.Document.GetWorksetId(oElement.Id);
            var worksetByElement = worksetTable.GetWorkset(worksetIdByElement);
            return worksetByElement.Name;
        }
    }
}
