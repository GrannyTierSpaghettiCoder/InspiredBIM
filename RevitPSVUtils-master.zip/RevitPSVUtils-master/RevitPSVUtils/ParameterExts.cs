﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class ParameterExts
    {
        public static void SetParameterByName(this ParameterSet paramSet, string name, string value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }

        public static void SetParameterByName(this ParameterSet paramSet, string name, double value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }
        public static void SetParameterByName(this ParameterSet paramSet, string name, int value)
        {
            foreach (Parameter parameter in paramSet)
            {
                if (parameter.Definition.Name.Equals(name))
                    parameter.Set(value);
            }
        }
    }
}
