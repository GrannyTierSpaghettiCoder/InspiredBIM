﻿using Autodesk.Revit.DB;
using RevitPSVUtils.EnumData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class WorkplaneUtils
    {
        public static SketchPlane CreatePlane(
            Document doc, string sketchPlaneName, WorkPlaneShow planeShow,
            ref Plane newPlane)
        {
            SketchPlane sketchPlane = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Delete family instances"))
            {
                t.Start();
                newPlane = Plane
                    .CreateByNormalAndOrigin(doc.ActiveView.ViewDirection, doc.ActiveView.Origin);
                sketchPlane = SketchPlane.Create(doc, newPlane);
                sketchPlane.Name = sketchPlaneName;
                doc.ActiveView.SketchPlane = sketchPlane;
                if (planeShow == WorkPlaneShow.On)
                {
                    doc.ActiveView.ShowActiveWorkPlane();
                }
                t.Commit();
            }
            return sketchPlane;
        }

        
    }
}
