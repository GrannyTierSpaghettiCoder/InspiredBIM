﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class MEPCurveExts
    {

        public static List<Connector> GetConnectors(this MEPCurve mepCurve)
        {
            var csi = mepCurve.ConnectorManager.Connectors.ForwardIterator();
            var connectors = new List<Connector>();

            while (csi.MoveNext())
            {
                var connector = csi.Current as Connector;
                connectors.Add(connector);
            }

            return connectors;
        }

        public static Curve GetCurve(this MEPCurve mepCurve)
        {
            //The wind pipe curve
            IList<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = mepCurve.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }
            Curve curve = Line.CreateBound(list.ElementAt(0), list.ElementAt(1)) as Curve;
            curve.MakeUnbound();
            return curve;
        }

        

        public static List<XYZ> GetStartAndEndPoint(this MEPCurve mepCurve)
        {
            //The wind pipe curve
            List<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = mepCurve.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }

            return list;
        }

        public static double GetLength(this MEPCurve mepCurve)
        {
            List<XYZ> startAndEndPoint = mepCurve.GetStartAndEndPoint();
            if (startAndEndPoint == null || startAndEndPoint.Count == 0 || startAndEndPoint.Count > 2 || (startAndEndPoint[0] == null || startAndEndPoint[1] == null))
                return 0;
            return startAndEndPoint[0].DistanceTo(startAndEndPoint[1]);
        }

        public static List<XYZ> SplitBySpecifiedDistance(this MEPCurve mepCurve, double splitDistance)
        {
            List<XYZ> xyzList = new List<XYZ>();
            double length1 = mepCurve.GetLength();
            List<XYZ> startAndEndPoint = mepCurve.GetStartAndEndPoint();
            XYZ point = startAndEndPoint[0];
            XYZ xyz1 = startAndEndPoint[1];
            XYZ direction = Line.CreateBound(point, xyz1).Direction;
            if (length1 == 0)
                return (List<XYZ>)null;
            int num = (int)(length1 / splitDistance);
            double length2 = 0;
            for (int index = 0; index < num; ++index)
            {
                length2 += splitDistance;
                XYZ xyz2 = point.MovePoint(direction, length2);
                xyzList.Add(xyz2);
            }
            return xyzList;
        }
        public static bool ConnectToWithUnionFitting(
            this MEPCurve oPipeFirst,
            MEPCurve oPipeSecond,
            ExternalCommandData commandData)
        {
            bool arePipesConnected = false;

            if (oPipeFirst.Equals(oPipeSecond))
                return arePipesConnected;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var pipeFirstConnectors = oPipeFirst.GetConnectors();
            var pipeSecondConnectors = oPipeSecond.GetConnectors();

            var oPipeFirstConnector1 = pipeFirstConnectors[0];
            var oPipeFirstConnector2 = pipeFirstConnectors[1];

            var oPipeSecondConnector1 = pipeSecondConnectors[0];
            var oPipeSecondConnector2 = pipeSecondConnectors[1];

            if (!oPipeFirstConnector1.IsValidObject || !oPipeFirstConnector2.IsValidObject ||
                !oPipeSecondConnector1.IsValidObject || !oPipeSecondConnector2.IsValidObject)
                return false;

            //Проверяем есть ли фитинги в той же точке, куда мы собрались его ставить

            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();

                //если один из коннекторов 1 трубы не соединен,
                //то проверяем находятся ли коннекторы 1 и 2 трубы в одной точки

                if (oPipeFirstConnector1.Origin.IsEqualByXYZ(oPipeSecondConnector1.Origin, 5))
                {
                    if (!oPipeFirstConnector1.IsConnected && !oPipeSecondConnector1.IsConnected)
                    {
                        FamilyInstance fitting = null;
                        try
                        {
                            fitting = doc.Create.NewUnionFitting(oPipeFirstConnector1, oPipeSecondConnector1);
                        }
                        catch (Exception)
                        {
                            return false;
                        }
                        var fittingConnectors = fitting.GetConnectors();
                        foreach (var fittingCon in fittingConnectors)
                        {
                            if (fittingCon.Origin.IsEqualByXYZ(oPipeFirstConnector1.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeFirstConnector1))
                                    fittingCon.ConnectTo(oPipeFirstConnector1);
                            }
                            else if (fittingCon.Origin.IsEqualByXYZ(oPipeSecondConnector1.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeSecondConnector1))
                                    fittingCon.ConnectTo(oPipeSecondConnector1);
                            }
                        }
                        arePipesConnected = true;
                    }
                }

                else if (oPipeFirstConnector1.Origin.IsEqualByXYZ(oPipeSecondConnector2.Origin, 5))
                {
                    if (!oPipeFirstConnector1.IsConnected && !oPipeSecondConnector2.IsConnected)
                    {
                        FamilyInstance fitting = null;

                        try
                        {
                            fitting = doc.Create.NewUnionFitting(oPipeFirstConnector1, oPipeSecondConnector2);

                        }
                        catch (Exception)
                        {
                            return false;
                        }
                        var fittingConnectors = fitting.GetConnectors();
                        foreach (var fittingCon in fittingConnectors)
                        {
                            if (fittingCon.Origin.IsEqualByXYZ(oPipeFirstConnector1.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeFirstConnector1))
                                    fittingCon.ConnectTo(oPipeFirstConnector1);
                            }
                            else if (fittingCon.Origin.IsEqualByXYZ(oPipeSecondConnector2.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeSecondConnector2))
                                    fittingCon.ConnectTo(oPipeSecondConnector2);
                            }
                        }
                        arePipesConnected = true;
                    }
                }
                if (oPipeFirstConnector2.Origin.IsEqualByXYZ(oPipeSecondConnector1.Origin, 5))
                {
                    FamilyInstance fitting = null;

                    if (!oPipeFirstConnector2.IsConnected && !oPipeSecondConnector1.IsConnected)
                    {
                        try
                        {
                            fitting = doc.Create.NewUnionFitting(oPipeFirstConnector2, oPipeSecondConnector1);
                        }
                        catch (Exception)
                        {
                            return false;
                        }
                        var fittingConnectors = fitting.GetConnectors();
                        foreach (var fittingCon in fittingConnectors)
                        {
                            if (fittingCon.Origin.IsEqualByXYZ(oPipeFirstConnector2.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeFirstConnector2))
                                    fittingCon.ConnectTo(oPipeFirstConnector2);
                            }
                            else if (fittingCon.Origin.IsEqualByXYZ(oPipeSecondConnector1.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeSecondConnector1))
                                    fittingCon.ConnectTo(oPipeSecondConnector1);
                            }
                        }
                        arePipesConnected = true;
                    }
                }
                else if (oPipeFirstConnector2.Origin.IsEqualByXYZ(oPipeSecondConnector2.Origin, 5))
                {
                    if (!oPipeFirstConnector2.IsConnected && !oPipeSecondConnector2.IsConnected)
                    {
                        FamilyInstance fitting = null;
                        try
                        {
                            fitting = doc.Create.NewUnionFitting(oPipeFirstConnector2, oPipeSecondConnector2);
                        }
                        catch (Exception)
                        {
                            return false;
                        }
                        var fittingConnectors = fitting.GetConnectors();
                        foreach (var fittingCon in fittingConnectors)
                        {
                            if (fittingCon.Origin.IsEqualByXYZ(oPipeFirstConnector2.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeFirstConnector2))
                                    fittingCon.ConnectTo(oPipeFirstConnector2);
                            }
                            else if (fittingCon.Origin.IsEqualByXYZ(oPipeSecondConnector2.Origin, 5))
                            {
                                if (!fittingCon.IsConnectedTo(oPipeSecondConnector2))
                                    fittingCon.ConnectTo(oPipeSecondConnector2);
                            }
                        }
                        arePipesConnected = true;
                    }
                }

                t.Commit();
            }

            return arePipesConnected;
        }
    }
}
