﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace RevitPSVUtils
{
    public class PlaneUtils
    {
        public static void CreateWorkplane(UIDocument uidoc, XYZ normal, XYZ origin, bool showWorkPlane)
        {
            var doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                var plane = Plane.CreateByNormalAndOrigin(normal, origin);
                var sketchPlane = SketchPlane.Create(doc, plane);
                uidoc.ActiveView.SketchPlane = sketchPlane;
                if(showWorkPlane)
                    uidoc.ActiveView.ShowActiveWorkPlane();
                t.Commit();
            }
        }
    }
}
