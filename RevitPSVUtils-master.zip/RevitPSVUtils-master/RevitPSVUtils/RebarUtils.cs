﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using RevitPSVUtils.EnumData;

namespace RevitPSVUtils
{
    public class RebarUtils
    {
        public static RebarContainer CreateRebarContainer(Document doc, Element host, RebarShape rebarShape,
            RebarBarType rebarType, XYZ startPoint, XYZ endPoint,
            int rebarCount, double rebarDistance, double rotationAngleDeg, XYZ norm, RebarStyle rebarStyle)
        {
            RebarContainer rebarContainer;
            using (var t = new Transaction(doc, "CreateMainRebars left rebar"))
            {
                t.Start();
                var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
                rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
                var line = Line.CreateBound(startPoint, endPoint);
                // Create the line rebar
                IList<Curve> curves = new List<Curve>();
                curves.Add(line);
                var item = rebarContainer.AppendItemFromCurves(
                    rebarStyle, rebarType, null, null, norm, curves,
                    RebarHookOrientation.Right, RebarHookOrientation.Left,
                    true, true);
                item.RebarShapeId = rebarShape.Id;
                item?.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, true, true, true);
                ElementTransformUtils.RotateElement(doc, rebarContainer.Id, line, NumberUtils.DegreesToRadians(rotationAngleDeg));
                rebarContainer.PresentItemsAsSubelements = true;
                t.Commit();
            }
            return rebarContainer;
        }

        public static Rebar CreateRebarByDefaultShape(Document doc, Element host,
            XYZ startPoint, XYZ endPoint, RebarBarType rebarType, XYZ norm)
        {
            var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
            var rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
            IList<Curve> curves = new List<Curve>();
            curves.Add(Line.CreateBound(startPoint, endPoint));
            var rebar = Rebar.CreateFromCurves(doc, RebarStyle.Standard,
                rebarType, null, null, host, norm,
                curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
            return rebar;
        }

        public static Rebar CreateRebarWithShape(Document doc, Element host,
            XYZ startPoint, XYZ endPoint, RebarBarType rebarType, RebarShape rebarShape, XYZ norm, RebarStyle rebarStyle)
        {
            var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
            var rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
            IList<Curve> curves = new List<Curve>();
            curves.Add(Line.CreateBound(startPoint, endPoint));
            var rebar = Rebar.CreateFromCurves(doc, rebarStyle,
                rebarType, null, null, host, norm,
                curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
            rebar.RebarShapeId = rebarShape.Id;
            return rebar;
        }

        public static Rebar CreateRebarWithShape(Document doc, Element host,
            XYZ startPoint, XYZ endPoint, RebarBarType rebarType, RebarShape rebarShape, XYZ norm,
            int rebarCount, double rebarDistance, bool barsOnNormalSide)
        {
            Rebar rebar = null;
            using (var t = new Transaction(doc, "Create rebar"))
            {
                t.Start();
                IList<Curve> curves = new List<Curve>();
                curves.Add(Line.CreateBound(startPoint, endPoint));
                rebar = Rebar.CreateFromCurves(doc, rebarShape.RebarStyle,
                    rebarType, null, null, host, norm,
                    curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
                rebar.RebarShapeId = rebarShape.Id;
                rebar.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, barsOnNormalSide, true, true);
                t.Commit();
            }
            return rebar;
        }

        public static Rebar CreateRebarWithShape(Document doc, Element host,
            XYZ startPoint, XYZ endPoint, RebarBarType rebarType, RebarShape rebarShape, XYZ norm,
            int rebarCount, double rebarDistance, bool barsOnNormalSide,
            Line axisOfRotation, double angleOfRotationDegree)
        {
            Rebar rebar = null;
            using (var t = new Transaction(doc, "Create rebar"))
            {
                t.Start();
                IList<Curve> curves = new List<Curve>();
                curves.Add(Line.CreateBound(startPoint, endPoint));
                rebar = Rebar.CreateFromCurves(doc, rebarShape.RebarStyle,
                    rebarType, null, null, host, norm,
                    curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
                rebar.RebarShapeId = rebarShape.Id;
                rebar.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, barsOnNormalSide, true, true);
                if (angleOfRotationDegree > 0)
                    ElementTransformUtils.RotateElement(doc, rebar.Id,
                    axisOfRotation, NumberUtils.DegreesToRadians(angleOfRotationDegree));
                t.Commit();
            }
            return rebar;
        }



        public static RebarContainer CreateRebarContainer(Document doc, Element host, RebarShape rebarShape,
            RebarBarType rebarType, XYZ startPoint, XYZ endPoint,
            int rebarCount, double rebarDistance, XYZ pointForRotationAxis1, XYZ pointForRotationAxis2, double rotationAngleDeg,
            XYZ norm)
        {
            var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
            var rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
            var rebar = CreateRebarByDefaultShape(doc, host, startPoint, endPoint, rebarType, norm);
            rebar.RebarShapeId = rebarShape.Id;
            var item = rebarContainer.AppendItemFromRebar(rebar);
            item?.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, true, true, true);
            var rotAxis = Line.CreateBound(pointForRotationAxis1, pointForRotationAxis2);
            ElementTransformUtils.RotateElement(
                doc, rebarContainer.Id,
                rotAxis, NumberUtils.DegreesToRadians(rotationAngleDeg));
            return rebarContainer;
        }

        public static RebarContainer CreateRebarContainer(
            Document doc, Element host, RebarShape rebarShape,
            RebarBarType rebarType, XYZ startPoint, XYZ endPoint,
            int rebarCount, double rebarDistance, XYZ norm)
        {
            var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
            var rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
            var item = rebarContainer.AppendItemFromCurves(RebarStyle.Standard, rebarType, null, null, norm,
                new List<Curve> { Line.CreateBound(startPoint, endPoint) },
                RebarHookOrientation.Left, RebarHookOrientation.Right, true, true);
            item.RebarShapeId = rebarShape.Id;
            item?.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, true, true, true);
            return rebarContainer;
        }

        public static RebarContainer CreateRebarContainerByExistedRebar(Document doc, Element host, Rebar rebar,
            int rebarCount, double rebarDistance, XYZ pointForRotationAxis1, XYZ pointForRotationAxis2,
            double rotationAngleDeg)
        {
            var defaultRebarContainerTypeId =
                RebarContainerType.CreateDefaultRebarContainerType(doc);
            var rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
            var item = rebarContainer.AppendItemFromRebar(rebar);
            item?.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, true, true, true);
            var rotAxis = Line.CreateBound(pointForRotationAxis1, pointForRotationAxis2);
            ElementTransformUtils.RotateElement(
                doc, rebarContainer.Id,
                rotAxis, NumberUtils.DegreesToRadians(rotationAngleDeg));
            return rebarContainer;
        }

        public static RebarContainer CreateRebarContainerByExistedRebar(Document doc, Element host, Rebar rebar,
            int rebarCount, double rebarDistance)
        {
            RebarContainer rebarContainer = null;
            RebarContainerItem rebarContainerItem = null;
            using (var t = new Transaction(doc, "Rebar"))
            {
                t.Start();
                var defaultRebarContainerTypeId =
                    RebarContainerType.CreateDefaultRebarContainerType(doc);
                rebarContainer = RebarContainer.Create(doc, host, defaultRebarContainerTypeId);
                rebarContainerItem = rebarContainer.AppendItemFromRebar(rebar);
                t.Commit();
            }
            using (var t = new Transaction(doc, "Rebar"))
            {
                t.Start();
                rebarContainerItem?.SetLayoutAsNumberWithSpacing(rebarCount, rebarDistance, true, true, true);
                t.Commit();
            }
            return rebarContainer;
        }
    }
}
