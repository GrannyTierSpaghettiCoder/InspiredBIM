﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class WallsUtils
    {
        public static List<Wall> GetAllTheWalls(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var oWalls =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(Wall))
                    .ToElements()
                    .Cast<Wall>()
                    .ToList();
            return oWalls;
        }
    }
}
