﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class ViewPlanUtils
    {
        public static List<ViewFamilyType> GetViewFamilyTypes(ExternalCommandData commandData, ViewFamily viewFamily)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var viewFamTypes = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewFamilyType))
                .Cast<ViewFamilyType>()
                .Where(v => v.ViewFamily == viewFamily)
                .ToList();
            return viewFamTypes;
        }

        public static ViewPlan CreateViewPlan(ExternalCommandData commandData,
                                              ElementId levelId)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            if (levelId == null)
                return null;
            var viewFamType = GetViewFamilyTypes(commandData, ViewFamily.FloorPlan).FirstOrDefault();
            if (viewFamType == null)
                return null;
            var viewPlan = ViewPlan.Create(doc, viewFamType.Id, levelId);
            return viewPlan;
        }

        public static bool IsViewPlanWithNameExists(ExternalCommandData commandData, string name)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var viewPlans = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewPlan))
                .Cast<ViewPlan>()
                .ToList();

            var viewPlanWithName = viewPlans.FirstOrDefault(v => v.Name == name);

            if (viewPlanWithName == null)
                return false;
            else
                return true;
        }

        public static List<View> GetViewPlanTemplates(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var viewPlans = new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                .Where(v => v.ViewType == ViewType.FloorPlan && v.IsTemplate)
                .ToList();

            return viewPlans;
        }
    }
}
