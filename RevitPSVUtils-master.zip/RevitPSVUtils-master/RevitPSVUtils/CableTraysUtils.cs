﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class CableTraysUtils
    {
        public static CableTray CreateNewCableTrayByTypeOfExisted(
                            CableTray existedCableTray, XYZ startPoint, XYZ endPoint, ExternalCommandData commandData)
        {

            if (startPoint.IsEqualByXYZ(endPoint))
                return null;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            if (!CableTray.IsValidLevelId(doc, existedCableTray.ReferenceLevel.Id))
            {
                return null;
            }

            if (!CableTray.IsValidCableTrayType(doc, existedCableTray.GetTypeId()))
            {
                return null;
            }

            //var cableTrayHeight = existedCableTray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).AsDouble();
            //var cableTrayWidth = existedCableTray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble();

            CableTray oCableTray = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                oCableTray = CableTray.Create(doc, existedCableTray.GetTypeId(), startPoint, endPoint,
                                            existedCableTray.ReferenceLevel.Id);
                existedCableTray.CopyParametersValueTo(oCableTray);

                //oCableTray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(cableTrayHeight);
                //oCableTray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(cableTrayWidth);
                t.Commit();
            }
            return oCableTray;
        }
    }
}
