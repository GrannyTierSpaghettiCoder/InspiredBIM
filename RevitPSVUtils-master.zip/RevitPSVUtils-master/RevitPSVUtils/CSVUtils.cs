﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class CSVUtils
    {
        public List<List<string>> ReadCSV(string fullPath, char csvDelimeter)
        {
            var listOfRows = new List<List<string>>();
            using (var reader = new StreamReader(fullPath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(csvDelimeter);
                    listOfRows.Add(values.ToList());
                }
            }
            return listOfRows;
        }
    }
}
