﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class TitleBlockUtils
    {
        public static List<FamilySymbol> GetTitleBlockFamilySymbols(ExternalCommandData commandData)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            var titleBlockFamSymbols = new FilteredElementCollector(doc)
                            .OfClass(typeof(FamilySymbol))
                            .OfCategory(BuiltInCategory.OST_TitleBlocks)
                            .Cast<FamilySymbol>()
                            .ToList();
            return titleBlockFamSymbols;
        }

        public static ViewSheet CreateSheet(ExternalCommandData commandData,
                                            ViewPlan viewPlan, FamilySymbol titleBlockFamSymbol)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            ViewSheet viewSheet = null;

            viewSheet = ViewSheet.Create(doc, titleBlockFamSymbol.Id);
            var sheetCenterPoint = viewSheet.get_BoundingBox(null).MiddlePointXYZ();
            //var viewSheetWidth = viewSheet.get_BoundingBox(null).GetXWidth();
            //var viewSheetHeight = viewSheet.get_BoundingBox(null).GetYHeight();
            var insertPoint = XYZ.Zero;
            Viewport.Create(doc, viewSheet.Id, viewPlan.Id, insertPoint);

            return viewSheet;
        }

        public static ViewSheet CreateSheet(ExternalCommandData commandData,
                                            ViewPlan viewPlan, FamilySymbol titleBlockFamSymbol, XYZ viewInsertPoint)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            ViewSheet viewSheet = null;

            viewSheet = ViewSheet.Create(doc, titleBlockFamSymbol.Id);
            var sheetCenterPoint = viewSheet.get_BoundingBox(null).MiddlePointXYZ();
            //var viewSheetWidth = viewSheet.get_BoundingBox(null).GetXWidth();
            //var viewSheetHeight = viewSheet.get_BoundingBox(null).GetYHeight();
            Viewport.Create(doc, viewSheet.Id, viewPlan.Id, viewInsertPoint);

            return viewSheet;
        }

        public static ViewSheet CreateSheet(ExternalCommandData commandData,
                                            FamilySymbol titleBlockFamSymbol)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            ViewSheet viewSheet = null;

            viewSheet = ViewSheet.Create(doc, titleBlockFamSymbol.Id);
            var sheetCenterPoint = viewSheet.get_BoundingBox(null).MiddlePointXYZ();
            //var viewSheetWidth = viewSheet.get_BoundingBox(null).GetXWidth();
            //var viewSheetHeight = viewSheet.get_BoundingBox(null).GetYHeight();
            return viewSheet;
        }
    }
}
