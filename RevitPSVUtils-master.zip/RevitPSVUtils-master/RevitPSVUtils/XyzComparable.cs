﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class XyzComparable : XYZ, IComparable<XYZ>
    {
        public XyzComparable(XYZ a)
          : base(a.X, a.Y, a.Z)
        {
        }

        int IComparable<XYZ>.CompareTo(XYZ a)
        {
            return Util.Compare(this, a);
        }
    }
}
