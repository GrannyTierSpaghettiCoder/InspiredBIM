﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class PipeAndWallIntersections
    {
        public Pipe oPipe { get; set; }
        public Wall oIntersectedWall { get; set; }
        public List<XYZ> intersectPoints { get; set; }
        public static PipeAndWallIntersections CreatePipeAndWallIntersectionPair(Pipe oPipe, Wall oWall)
        {

            var oPipeCurve = oPipe.GetPipeCurve();
            var oWallFaces = oWall.GetWallFaces();
            XYZ intersectionResult = null;
            foreach (var oWallFace in oWallFaces)
            {
                //The intersection point
                IntersectionResultArray intersectionR = new IntersectionResultArray();//Intersection point set

                SetComparisonResult results;//Results of Comparison

                results = oWallFace.Intersect(oPipeCurve, out intersectionR);

                if (SetComparisonResult.Disjoint != results
                    && intersectionR != null
                    && !intersectionR.IsEmpty)
                {

                    intersectionResult = intersectionR.get_Item(0).XYZPoint;
                    return new PipeAndWallIntersections
                    {
                        oPipe = oPipe,
                        oIntersectedWall = oWall,
                        intersectPoints = new List<XYZ>()
                                {
                                    intersectionResult
                                }
                    };
                }
            }
            return null;
        }

        public static List<PipeAndWallIntersections> CreatePipeAndWallIntersectionPairs(List<Pipe> oPipes, List<Wall> oWalls)
        {
            var pairs = new List<PipeAndWallIntersections>();
            foreach (var oPipe in oPipes)
            {
                foreach (var oWall in oWalls)
                {
                    var pair = CreatePipeAndWallIntersectionPair(oPipe, oWall);
                    if (pair != null)
                    {
                        pairs.Add(pair);
                    }
                }
            }
            return pairs;
        }
    }
}
