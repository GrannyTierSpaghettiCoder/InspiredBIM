﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using RevitPSVUtils.EnumData;

namespace RevitPSVUtils
{
    public class LineUtils
    {
        public static Line CreateLineByPointAndDirection(XYZ point, Direction direction, double length)
        {
            Line oLine = null;
            switch (direction)
            {
                case Direction.X:
                    oLine = Line.CreateBound(new XYZ(point.X - length, point.Y, point.Z),
                        new XYZ(point.X + length, point.Y, point.Z));
                    break;
                case Direction.Y:
                    oLine = Line.CreateBound(new XYZ(point.X, point.Y - length, point.Z),
                        new XYZ(point.X, point.Y + length, point.Z));
                    break;
                default:
                    oLine = Line.CreateBound(new XYZ(point.X, point.Y, point.Z - length),
                        new XYZ(point.X, point.Y, point.Z + length));
                    break;
            }

            return oLine;
        }

        public static Line CreateLineByPointAndDirection(XYZ point, XYZ direction, double length)
        {
            direction = direction / direction.GetLength();
            XYZ endPoint = point + length * direction;
            Line line = Line.CreateBound(point, endPoint);
            return line;
        }
    }
}
