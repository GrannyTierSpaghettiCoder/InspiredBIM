﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class FamilyParameterExts
    {
        public static void SetValue(this FamilyParameter famParam, Document familyDoc, object value)
        {
            if (familyDoc == null || famParam == null || value == null || famParam.IsReadOnly)
                return;

            var famManager = familyDoc.FamilyManager;

            using (var t = new Autodesk.Revit.DB.Transaction(familyDoc, "Set parameters to all types"))
            {
                t.Start();
                if (famParam.IsDeterminedByFormula)
                    famManager.SetFormula(famParam, null);
                foreach (FamilyType famType in famManager.Types)
                {
                    famManager.CurrentType = famType;
                    if (famParam.StorageType == StorageType.Double)
                    {
                        famManager.Set(famParam, (double)value);
                    }
                    else if (famParam.StorageType == StorageType.Integer)
                    {
                        famManager.Set(famParam, (int)value);
                    }
                    else if (famParam.StorageType == StorageType.String)
                    {
                        famManager.Set(famParam, (string)value);
                    }
                    else if (famParam.StorageType == StorageType.ElementId)
                    {
                        famManager.Set(famParam, (ElementId)value);
                    }
                }
                t.Commit();
            }
        }

        public static void SwitchTypeOrInstance(this FamilyParameter famParam, Document familyDoc)
        {
            if (famParam.IsBuiltInParam() || famParam.IsDeterminedByFormula || familyDoc == null ||
                famParam == null)
                return;

            var famManager = familyDoc.FamilyManager;

            using (var t = new Transaction(familyDoc, "Switch type or instance"))
            {
                t.Start();
                if (famParam.IsInstance == true)
                    famManager.MakeType(famParam);
                else
                    famManager.MakeInstance(famParam);
                t.Commit();
            }
        }

        public static void SetParameterFormula(this FamilyParameter famParam, Document familyDoc, string formula)
        {

            if (familyDoc == null || famParam == null || formula == null || famParam.IsReadOnly)
                return;
            var famManager = familyDoc.FamilyManager;

            using (var t = new Transaction(familyDoc, "Set formula"))
            {
                t.Start();
                famManager.SetFormula(famParam, formula);
                t.Commit();
            }
        }

        public static void SetParameterName(this FamilyParameter famParam, Document familyDoc, string name)
        {
            var famManager = familyDoc.FamilyManager;

            if (famParam.IsBuiltInParam())
            {
                return;
            }

            if (!famParam.IsShared)
            {
                using (var t = new Autodesk.Revit.DB.Transaction(familyDoc, "Set new parameter name"))
                {
                    t.Start();
                    famManager.RenameParameter(famParam, name);
                    t.Commit();
                }
            }
        }
    }
}
