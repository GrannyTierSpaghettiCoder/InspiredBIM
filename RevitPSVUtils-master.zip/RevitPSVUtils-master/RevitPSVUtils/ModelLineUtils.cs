﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RevitPSVUtils
{
    public class ModelLineUtils
    {
        public static List<XYZ> GetModelLinePoints(List<ModelLine> modelLines)
        {
            var points = new List<XYZ>();
            foreach (var modelLine in modelLines)
            {
                points.Add(modelLine.GeometryCurve.GetEndPoint(0));
                points.Add(modelLine.GeometryCurve.GetEndPoint(1));
            }
            return points;
        }


        public static Result Create3DModelLine(UIApplication pUiapp, XYZ p, XYZ q, string pstrLineStyle, bool pblnIsFamily)
        {
            Document doc = pUiapp.ActiveUIDocument.Document;
            Result lresResult = Result.Failed;
            using (Transaction tr = new Transaction(doc, "Create3DModelLine"))
            {
                tr.Start();
                try
                {
                    if (p.IsAlmostEqualTo(q))
                    {
                        throw new System.ArgumentException("Expected two different points.");
                    }
                    Line line = Line.CreateBound(p, q);
                    if (null == line)
                    {
                        throw new Exception("Geometry line creation failed.");
                    }
                    ModelCurve mCurve = null;
                    if (pblnIsFamily)
                    {
                        mCurve = doc.FamilyCreate.NewModelCurve(line, NewSketchPlanePassLine(pUiapp, line)); // not needed , pblnIsFamily));
                    }
                    else
                    {
                        mCurve = doc.Create.NewModelCurve(line, NewSketchPlanePassLine(pUiapp, line)); // not needed , pblnIsFamily));
                    }
                    // set linestyle
                    ICollection<ElementId> styles = mCurve.GetLineStyleIds();
                    foreach (ElementId eid in styles)
                    {
                        Element e = doc.GetElement(eid);
                        if (e.Name == pstrLineStyle)
                        {
                            mCurve.LineStyle = e;
                            break;
                        }
                    }
                    tr.Commit();
                    lresResult = Result.Succeeded;
                }
                catch (Autodesk.Revit.Exceptions.ExternalApplicationException ex)
                {
                    MessageBox.Show(ex.Source + Environment.NewLine + ex.StackTrace + Environment.NewLine + ex.Message);
                    // tr.RollBack();
                }
            }
            return lresResult;
        }

        static SketchPlane NewSketchPlanePassLine(UIApplication pUiapp, Line line)
        {
            Document doc = pUiapp.ActiveUIDocument.Document;
            XYZ p = line.GetEndPoint(0);
            XYZ q = line.GetEndPoint(1);
            XYZ norm;
            if (p.X == q.X)
            {
                norm = XYZ.BasisX;
            }
            else if (p.Y == q.Y)
            {
                norm = XYZ.BasisY;
            }
            else
            {
                norm = XYZ.BasisZ;
            }
            Plane plane = Plane.CreateByNormalAndOrigin(norm, p);
            SketchPlane skPlane = SketchPlane.Create(doc, plane);
            return skPlane;
        }

        public static ModelLine CreateModelLineUsingActiveView(Document doc, XYZ startPoint, XYZ endPoint)
        {
            ModelLine line = null;
            using (Transaction tr = new Transaction(doc, "Create3DModelLine"))
            {
                tr.Start();
                // get handle to application from document
                Autodesk.Revit.ApplicationServices.Application application = doc.Application;

                Line geomLine = Line.CreateBound(startPoint, endPoint);

                // Create a geometry arc in Revit application

                // Create a geometry plane in Revit application
                XYZ origin = doc.ActiveView.Origin;
                XYZ normal = doc.ActiveView.ViewDirection;

                Plane geomPlane = Plane.CreateByNormalAndOrigin(normal, origin);

                // Create a sketch plane in current document
                SketchPlane sketch = SketchPlane.Create(doc, geomPlane);

                // Create a ModelLine element using the created geometry line and sketch plane
                line = doc.Create.NewModelCurve(geomLine, sketch) as ModelLine;
                tr.Commit();
            }
            return line;
        }
    }
}
