﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class LevelUtils
    {
        public static List<Level> GetLevels(ExternalCommandData commandData)
        {
            var levels = new List<Level>();
            var doc = commandData.Application.ActiveUIDocument.Document;
            var active = doc.ActiveView;
            FilteredElementCollector lvlCollector = new FilteredElementCollector(doc);
            ICollection<Element> lvlCollection = lvlCollector.OfClass(typeof(Level)).ToElements();
            foreach (Element l in lvlCollection)
            {
                Level level = l as Level;
                levels.Add(level);
            }
            return levels;
        }
    }
}
