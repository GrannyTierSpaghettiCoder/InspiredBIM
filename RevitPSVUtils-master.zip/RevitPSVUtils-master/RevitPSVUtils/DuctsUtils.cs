﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class DuctsUtils
    {
        public static List<Duct> GetAllTHeDuctSegments(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            //собираем все воздуховоды
            var oDucts =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(Duct))
                    .ToElements()
                    .Cast<Duct>()
                    .ToList();
            return oDucts;
        }

        public static Duct CreateNewDuctByTypeOfExisted(
                            Duct existedDuct, XYZ startPoint, XYZ endPoint, ExternalCommandData commandData)
        {

            if (startPoint.IsEqualByXYZ(endPoint, 5))
                return null;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            if (!Duct.IsLevelId(doc, existedDuct.ReferenceLevel.Id))
            {
                return null;
            }

            if (!Duct.IsDuctTypeId(doc, existedDuct.DuctType.Id))
            {
                return null;
            }
            if (existedDuct.MEPSystem == null)
            {
                return null;
            }

            Duct oDuct = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                oDuct = Duct.Create(doc, existedDuct.MEPSystem.GetTypeId(),
                    existedDuct.DuctType.Id, existedDuct.ReferenceLevel.Id, startPoint, endPoint);
                existedDuct.CopyParametersValueTo(oDuct);
                t.Commit();
            }
            return oDuct;
        }
    }
}
