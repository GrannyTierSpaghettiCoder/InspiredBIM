﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitPSVUtils
{
    public static class ElementExts
    {
        public static void Rotate(this Element element, Line axis, double angleDegree)
        {

            using (var t = new Transaction(element.Document, "Rebar"))
            {
                t.Start();
                ElementTransformUtils.RotateElement(
                    element.Document, element.Id,
                    axis, NumberUtils.DegreesToRadians(angleDegree));
                t.Commit();
            }
        }

        public static bool GetParameterValue(this Element oElement, string parameterName,
            ref string stringValue,
            ref double doubleValue,
            ref int intValue)
        {
            var parameter = oElement.LookupParameter(parameterName);
            if (parameter == null)
                return false;
            if (parameter.StorageType == StorageType.String)
            {
                stringValue = parameter.AsString();
            }
            else if (parameter.StorageType == StorageType.Double)
            {
                doubleValue = parameter.AsDouble();
            }
            else if (parameter.StorageType == StorageType.Integer)
            {
                intValue = parameter.AsInteger();
            }
            else
            {
                return false;
            }
            return true;
        }

        public static bool GetParameterValue(this Element oElement, string parameterName,
            ref string stringValue,
            ref double doubleValue,
            ref int intValue,
            ref ElementId elementIdValue)
        {
            var parameter = oElement.LookupParameter(parameterName);
            if (parameter == null)
                return false;
            if (parameter.StorageType == StorageType.String)
            {
                stringValue = parameter.AsString();
            }
            else if (parameter.StorageType == StorageType.Double)
            {
                doubleValue = parameter.AsDouble();
            }
            else if (parameter.StorageType == StorageType.Integer)
            {
                intValue = parameter.AsInteger();
            }
            else if (parameter.StorageType == StorageType.ElementId)
            {
                elementIdValue = parameter.AsElementId();
            }
            else
            {
                return false;
            }
            return true;
        }

        public static string GetParameterValueToString(this Element oElement, string parameterName)
        {
            var parameter = oElement.LookupParameter(parameterName);
            var parameterValue = string.Empty;
            if (parameter == null)
                return parameterValue;
            if (parameter.StorageType == StorageType.String)
            {
                parameterValue = parameter.AsString();
            }
            else if (parameter.StorageType == StorageType.Double)
            {
                parameterValue = parameter.AsDouble().ToString();
            }
            else if (parameter.StorageType == StorageType.Integer)
            {
                parameterValue = parameter.AsInteger().ToString();
            }
            else if (parameter.StorageType == StorageType.ElementId)
            {
                parameterValue = parameter.AsElementId().ToString();
            }
            else
            {
                return parameterValue;
            }
            return parameterValue;
        }

        public static Level GetLevel(this Element oElement, ExternalCommandData commandData)
        {
            Document document = commandData.Application.ActiveUIDocument.Document;
            Level level = (Level)null;
            using (Transaction transaction = new Transaction(document, "Get level"))
            {
                transaction.Start();
                level = document.GetElement(oElement.LevelId) as Level;
                if (level == null)
                    return null;
                transaction.Commit();
            }
            return level;
        }

        public static bool GetTypeParameterValue(this Element oElement, string parameterName,
            ref string stringValue,
            ref double doubleValue,
            ref int intValue,
            ref ElementId elementIdValue)
        {
            Element elementType = oElement.Document.GetElement(oElement.GetTypeId());

            var parameter = elementType.LookupParameter(parameterName);
            if (parameter == null)
                return false;
            if (parameter.StorageType == StorageType.String)
            {
                stringValue = parameter.AsString();
            }
            else if (parameter.StorageType == StorageType.Double)
            {
                doubleValue = parameter.AsDouble();
            }
            else if (parameter.StorageType == StorageType.Integer)
            {
                intValue = parameter.AsInteger();
            }
            else if (parameter.StorageType == StorageType.ElementId)
            {
                elementIdValue = parameter.AsElementId();
            }
            else
            {
                return false;
            }
            return true;
        }

        public static double GetOffset(this Element oElement)
        {
            Parameter parameter = oElement.LookupParameter("Offset") ?? oElement.LookupParameter("Смещение");
            if (parameter == null || parameter.StorageType != StorageType.Double)
                return 0;
            return parameter.AsDouble();
        }

        public static List<List<XYZ>> GetEdgePointsFromElement(
            this Element oElement)
        {
            var edgePointsList = new List<List<XYZ>>();

            var options = new Options();
            //options.DetailLevel = ViewDetailLevel.Fine;
            options.View = ViewUtils.Get3dView(oElement.Document);
            var geomElement = oElement.get_Geometry(options);
            foreach (GeometryObject geomObject in geomElement)
            {
                var solid = geomObject as Solid;
                if (null == solid || 0 == solid.Faces.Size || 0 == solid.Edges.Size)
                {
                    continue;
                }

                foreach (Edge edge in solid.Edges)
                {
                    var edgePoints = new List<XYZ>();
                    foreach (XYZ edgeVertice in edge.Tessellate())
                    {
                        //XYZ point = ii;
                        //XYZ transformedPoint = instTransform.OfPoint(point);
                        edgePoints.Add(edgeVertice);
                    }
                    edgePointsList.Add(edgePoints);
                }
            }
            return edgePointsList;
        }

        public static List<List<XYZ>> GetFacePointsFromElement(
            this Element oElement)
        {
            var facePointsList = new List<List<XYZ>>();

            var options = new Options();
            options.View = ViewUtils.Get3dView(oElement.Document);
            var geomElement = oElement.get_Geometry(options);
            foreach (GeometryObject geomObject in geomElement)
            {
                var solid = geomObject as Solid;
                if (null == solid || 0 == solid.Faces.Size || 0 == solid.Edges.Size)
                {
                    continue;
                }

                foreach (Face face in solid.Faces)
                {
                    Mesh mesh = face.Triangulate();
                    var facePoints = new List<XYZ>();
                    foreach (XYZ meshVertice in mesh.Vertices)
                    {
                        facePoints.Add(meshVertice);
                    }
                    facePointsList.Add(facePoints);
                }

            }
            return facePointsList;
        }


        public static List<Face> GetFacesFromElement(
            this Element oElement)
        {
            var faceList = new List<Face>();

            var options = new Options();
            options.View = ViewUtils.Get3dView(oElement.Document);
            var geomElement = oElement.get_Geometry(options);
            foreach (GeometryObject geomObject in geomElement)
            {
                var solid = geomObject as Solid;
                if (null == solid || 0 == solid.Faces.Size || 0 == solid.Edges.Size)
                {
                    continue;
                }

                foreach (Face face in solid.Faces)
                {

                    faceList.Add(face);
                }

            }
            return faceList;
        }

        public static XYZ GetMiddlePoint(this Element element)
        {
            var bbox = element.get_BoundingBox(null);
            if (bbox == null)
                return null;

            var midPoint = bbox.MiddlePointXYZ();
            return midPoint;
        }

        public static XYZ GetMiddlePointWithMaxZ(this Element element)
        {
            var bbox = element.get_BoundingBox(null);
            if (bbox == null)
                return null;

            var midPoint = bbox.MiddlePointXYZ();
            var midPointMaxZ = new XYZ(midPoint.X, midPoint.Y, bbox.Max.Z);
            return midPointMaxZ;
        }

        public static XYZ GetMiddlePoint(this Element element, View3D view3d)
        {
            var bbox = element.get_BoundingBox(view3d);
            if (bbox == null)
                return null;

            var midPoint = bbox.MiddlePointXYZ();
            return midPoint;
        }

        public static void CopyParametersValueTo(this Element oSourceElement, Element targetElement)
        {

            foreach (Parameter sourceElementParameter in oSourceElement.Parameters)
            {
                if (sourceElementParameter.IsReadOnly)
                    continue;

                string stringValue = null;
                int intValue = 0;
                double doubleValue = 0;
                ElementId elementIdValue = null;
                var sourceParameterName = sourceElementParameter.Definition.Name;
                oSourceElement.GetParameterValue(sourceParameterName, ref stringValue,
                    ref doubleValue, ref intValue, ref elementIdValue);

                if (stringValue != null)
                    targetElement.LookupParameter(sourceParameterName).Set(stringValue);
                else if (intValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(intValue);
                else if (doubleValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(doubleValue);
                else if (elementIdValue != null)
                    targetElement.LookupParameter(sourceParameterName).Set(elementIdValue);

            }
        }
        public static void CopyParametersValueTo(
            this Element oSourceElement,
            Element targetElement,
            bool IsIncludeElementIdParam)
        {
            foreach (Parameter sourceElementParameter in oSourceElement.Parameters)
            {
                if (sourceElementParameter.IsReadOnly)
                    continue;

                string stringValue = null;
                int intValue = 0;
                double doubleValue = 0;
                ElementId elementIdValue = null;
                var sourceParameterName = sourceElementParameter.Definition.Name;
                oSourceElement.GetParameterValue(sourceParameterName, ref stringValue,
                    ref doubleValue, ref intValue, ref elementIdValue);

                if (stringValue != null)
                    targetElement.LookupParameter(sourceParameterName).Set(stringValue);
                else if (intValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(intValue);
                else if (doubleValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(doubleValue);
                else if (elementIdValue != null)
                {
                    if (IsIncludeElementIdParam)
                        targetElement.LookupParameter(sourceParameterName).Set(elementIdValue);
                }
            }
        }

        public static void CopyParametersValueTo(
            this Element oSourceElement,
            Element targetElement,
            List<string> paramNameContainsToExcludeList)
        {
            foreach (Parameter sourceElementParameter in oSourceElement.Parameters)
            {
                if (sourceElementParameter.IsReadOnly)
                    continue;

                string stringValue = null;
                int intValue = 0;
                double doubleValue = 0;
                ElementId elementIdValue = null;
                var sourceParameterName = sourceElementParameter.Definition.Name;

                //Проверяем наличие параметров для исключения
                //если найдём - переходим к следующему параметру
                bool isExcludeParamFound = false;
                foreach (var paramNameContainsToExclude in paramNameContainsToExcludeList)
                {
                    if (sourceParameterName.Contains(paramNameContainsToExclude))
                    {
                        isExcludeParamFound = true;
                        break;
                    }
                }

                if (isExcludeParamFound)
                    continue;

                oSourceElement.GetParameterValue(sourceParameterName, ref stringValue,
                    ref doubleValue, ref intValue, ref elementIdValue);

                if (stringValue != null)
                    targetElement.LookupParameter(sourceParameterName).Set(stringValue);
                else if (intValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(intValue);
                else if (doubleValue != 0)
                    targetElement.LookupParameter(sourceParameterName).Set(doubleValue);
                else if (elementIdValue != null)
                    targetElement.LookupParameter(sourceParameterName).Set(elementIdValue);
            }
        }

        public static List<Parameter> GetParameters(this Element oElement)
        {
            var parameters = new List<Parameter>();
            foreach (Parameter elementParameter in oElement.Parameters)
            {
                if (elementParameter.IsReadOnly)
                    continue;
                parameters.Add(elementParameter);
            }

            return parameters;
        }

        public static XYZ GetElementCenter(this Element elem)
        {
            BoundingBoxXYZ bounding = elem.get_BoundingBox(null);
            XYZ center = (bounding.Max + bounding.Min) * 0.5;
            return center;
        }
    }
}
