﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;

namespace RevitPSVUtils
{
    public class PromptUtils<T>
    {
        public static List<T> GetObjects(ExternalCommandData commandData, string promptMessage, Type type)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            IList<Reference> selectedObjs = null;
            try
            {
                selectedObjs = uidoc.Selection.PickObjects(ObjectType.Element, promptMessage);
            }
            catch (Exception)
            {
                return new List<T>();
            }
            var elements = new List<T>();
            foreach (var selectedObj in selectedObjs)
            {
                var elem = doc.GetElement(selectedObj.ElementId);
                if (type == elem.GetType())
                {
                    elements.Add((T)(object)elem);
                }
            }
            return elements;
        }

        public static List<T> GetObjects(ExternalCommandData commandData, string promptMessage)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            var selectedObjs = uidoc.Selection.PickObjects(ObjectType.Element, promptMessage);
            if (selectedObjs == null)
                return null;
            var elements = new List<T>();
            foreach (var selectedObj in selectedObjs)
            {
                var elem = doc.GetElement(selectedObj.ElementId);
                if (typeof(T).Equals(elem.GetType()))
                {
                    elements.Add((T)(object)elem);
                }
            }
            return elements;
        }

        public static T GetObject(ExternalCommandData commandData, string promptMessage, Type type)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            Reference selectedObj = null;
            T elem;
            try
            {
                selectedObj = uidoc.Selection.PickObject(ObjectType.Element, promptMessage);
            }
            catch (Exception)
            {
            }
            elem = (T)(object)doc.GetElement(selectedObj.ElementId);
            if (type.Equals(elem.GetType()))
            {
                return elem;
            }
            return elem;
        }
    }
}
