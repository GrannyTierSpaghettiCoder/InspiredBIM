﻿
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class PipesUtils
    {
        public static List<Pipe> GetAllThePipeSegments(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var oPipes =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(Pipe))
                    .ToElements()
                    .Cast<Pipe>()
                    .ToList();
            return oPipes;
        }

        public static List<PipeType> GetPipeTypes(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var oPipeTypes =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(PipeType))
                    .ToElements()
                    .Cast<PipeType>()
                    .ToList();
            return oPipeTypes;
        }

        public static Pipe CreateNewPipeByTypeOfExisted(
                            Pipe existedPipe, XYZ startPoint, XYZ endPoint, ExternalCommandData commandData)
        {

            if (startPoint.IsEqualByXYZ(endPoint))
                return null;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            //Проверяем допустимую длину трубы
            var curveTolerance = commandData.Application.Application.ShortCurveTolerance;
            if (startPoint.DistanceTo(endPoint) <= curveTolerance)
                return null;

            if (!Pipe.IsLevelId(doc, existedPipe.ReferenceLevel.Id))
            {
                return null;
            }

            if (!Pipe.IsPipeTypeId(doc, existedPipe.PipeType.Id))
            {
                return null;
            }
            if (existedPipe.MEPSystem == null)
            {
                return null;
            }

            Pipe oPipe = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                oPipe = Pipe.Create(doc, existedPipe.MEPSystem.GetTypeId(),
                    existedPipe.PipeType.Id, existedPipe.ReferenceLevel.Id, startPoint, endPoint);
                existedPipe.CopyParametersValueTo(oPipe, new List<string> { "Смещение", "Offset" });

                t.Commit();
            }
            return oPipe;
        }

        public static Pipe Create(PipeType oPipeType, XYZ startPoint, XYZ endPoint,
            double desiredOuterDiameter,
            ExternalCommandData commandData)
        {

            if (startPoint.IsEqualByXYZ(endPoint))
                return null;

            var curveTolerance = commandData.Application.Application.ShortCurveTolerance;
            if (startPoint.DistanceTo(endPoint) <= curveTolerance)
                return null;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var mepSystemTypes
                  = new FilteredElementCollector(doc)
                    .OfClass(typeof(PipingSystemType))
                    .OfType<PipingSystemType>()
                    .ToList();


            var level = LevelUtils.GetLevels(commandData).FirstOrDefault();


            Pipe oPipe = null;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Create pipe"))
            {
                t.Start();
                oPipe = Pipe.Create(doc, mepSystemTypes.FirstOrDefault().Id,
                    oPipeType.Id, level.Id, startPoint, endPoint);

                var chosenSize = GetNearestSizeByOuterDiameter(oPipe, desiredOuterDiameter);
                if (chosenSize == null)
                    return null;
                oPipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
                        .Set(chosenSize.NominalDiameter);
                t.Commit();
            }

            return oPipe;
        }

        public static MEPSize GetNearestSizeByOuterDiameter(Pipe oPipe, double desiredOuterDiameter)
        {
            var sizesList = GetMEPSizesOfPipe(oPipe);
            var outerDiameters = sizesList.Select(s => s.OuterDiameter).ToList();

            var nearesOuterDiameter = NumberUtils.FindNearestValue(outerDiameters, desiredOuterDiameter);

            var chosenSize = sizesList.FirstOrDefault(s => s.OuterDiameter.Equals(nearesOuterDiameter));
            return chosenSize;
        }

        public static List<MEPSize> GetMEPSizesOfPipe(Pipe oPipe)
        {
            var routingManager = oPipe.PipeType.RoutingPreferenceManager;
            var segmenetRulesCount = routingManager.GetNumberOfRules(RoutingPreferenceRuleGroupType.Segments);

            var sizesList = new List<MEPSize>();

            for (int i = 0; i < segmenetRulesCount; i++)
            {
                var segmentRule = routingManager.GetRule(RoutingPreferenceRuleGroupType.Segments, i);
                var segment = oPipe.Document.GetElement(segmentRule.MEPPartId) as Segment;
                sizesList.AddRange(segment.GetSizes());
            }

            return sizesList;
        }
    }
}
