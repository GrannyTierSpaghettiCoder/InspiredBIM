﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class ScheduleUtils
    {
        public static List<ViewSchedule> GetAllTheSchedules(ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            //get instances of category
            return new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSchedule))
                .Cast<ViewSchedule>()
                .Where(s => !s.Name.Equals("<Revision Schedule>"))
                .ToList();
        }

        public static List<ViewSchedule> GetAllTheSchedules(Document doc)
        {
            //get instances of category
            return new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSchedule))
                .Cast<ViewSchedule>()
                .Where(s => !s.Name.Equals("<Revision Schedule>"))
                .ToList();
        }

        public static List<ViewSchedule> GetSchedulesOfCategory(List<ViewSchedule> schedules, Category filterCategory, Document doc)
        {
            var schedulesOfCategory = new List<ViewSchedule>();

            foreach (var schedule in schedules)
            {
                var scheduleCategoryId = schedule.Definition.CategoryId;
                if (filterCategory.Id == scheduleCategoryId)
                {
                    schedulesOfCategory.Add(schedule);
                }
            }

            return schedulesOfCategory;
        }

        public static ViewSchedule CopySchedule(ViewSchedule viewSchedule)
        {
            if (viewSchedule == null)
                return null;
            var copiedScheduleId = ElementTransformUtils.CopyElement(viewSchedule.Document, viewSchedule.Id,
                                              XYZ.Zero).FirstOrDefault();
            if (copiedScheduleId == null)
                return null;

            var copiedSchedule = viewSchedule.Document.GetElement(copiedScheduleId) as ViewSchedule;
            if (copiedSchedule == null)
                return null;

            return copiedSchedule;
        }

        public static ScheduleField FindField(ViewSchedule schedule, string parameterName)
        {
            ScheduleDefinition definition = schedule.Definition;
            var fieldCount = definition.GetFieldCount();

            for (int i = 0; i < fieldCount; i++)
            {
                var field = definition.GetField(i);
                var fieldName = field.GetName();

                if (fieldName == parameterName)
                    return definition.GetField(i);
            }

            return null;
        }

        public static SchedulableField FindSchedulableField(ViewSchedule schedule, string parameterName)
        {

            var schedulableField = schedule.Definition
                    .GetSchedulableFields()
                    .FirstOrDefault(p => p.GetName(schedule.Document) == parameterName);
            return schedulableField;
        }

        public static void AddFilterToSchedule(ViewSchedule schedule,
                                                string parameterName, string parameterValue)
        {

            var scheduleDef = schedule.Definition;
            if (scheduleDef == null)
                return;

            //Находим поле СО, если его нет - добавляем
            var field = FindField(schedule, parameterName);


            if (field == null)
            {
                var schedulableField = FindSchedulableField(schedule, parameterName);
                if (schedulableField == null)
                    return;
                field = scheduleDef.AddField(schedulableField);
            }
            if (field == null)
                return;

            var filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Equal, parameterValue);
            if (filter == null)
                return;

            scheduleDef.AddFilter(filter);
        }
    }
}
