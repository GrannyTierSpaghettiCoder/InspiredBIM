﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class PhaseUtils
    {
        public static List<Phase> GetPhases(Document doc)
        {
            var phases = new List<Phase>();
            foreach (Phase phase in doc.Phases)
            {
                phases.Add(phase);
            }
            return phases;
        }
    }
}
