﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class XYZUtils
    {
        public static bool IsInPolygonBy2d(List<XYZ> polygon, XYZ point)
        {

            var coef = polygon.Skip(1).Select((p, i) =>
                                           (point.Y - polygon[i].Y) * (p.X - polygon[i].X)
                                         - (point.X - polygon[i].X) * (p.Y - polygon[i].Y))
                                   .ToList();

            if (coef.Any(p => p == 0))
                return true;

            for (int i = 1; i < coef.Count(); i++)
            {
                if (coef[i] * coef[i - 1] < 0)
                    return false;
            }
            return true;
        }
    }
}
