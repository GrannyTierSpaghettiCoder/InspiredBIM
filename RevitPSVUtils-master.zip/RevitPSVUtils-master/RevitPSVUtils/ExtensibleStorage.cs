﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using RevitPSVUtils.EnumData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RevitPSVUtils
{
    public class ExtensibleStorage<T>
    {
        //Поля
        public SchemaBuilder SchemaBuilder { get; set; }
        public Schema SchemaProp { get; set; }
        public Document Doc { get; set; }
        public FieldBuilder Field { get; set; }
        public Entity EntityProp { get; set; }
        public List<Element> ElementModel { get; set; }
        public Transaction TransactionProp { get; set; }

        //Статик
        public static ExtensibleStorage<T> CreateExtStorage(string schemaName, Document doc)
        {
            var extStorage = new ExtensibleStorage<T>();
            //присваиваем текущий документ
            extStorage.Doc = doc;
            //смотрим существует ли схема уже
            var existedSchema = extStorage.GetSchemaByName(schemaName);
            //если схемы нет, то создаём её
            if (existedSchema == null)
            {
                extStorage.CreateSchemaBuilder(schemaName, doc);
            }
            //если схема есть, то применяем её
            else
            {
                extStorage.SchemaProp = existedSchema;
                extStorage.EntityProp = new Entity(existedSchema);
            }
            return extStorage;
        }

        //Методы
        public void CreateSchemaBuilder(string schemaName, Document doc)
        {
            using (var t = new Transaction(doc, "Create schema builder"))
            {
                t.Start();
                var schemaBuilder = new SchemaBuilder(Guid.NewGuid());
                schemaBuilder.SetReadAccessLevel(AccessLevel.Public); // any can read
                schemaBuilder.SetWriteAccessLevel(AccessLevel.Public); // anyone can write
                schemaBuilder.SetSchemaName(schemaName);
                this.SchemaBuilder = schemaBuilder;
                //this.SchemaProp = this.SchemaBuilder.Finish();
                this.TransactionProp = t;
                t.Commit();
            }
        }

        public void FinishSchemaBuilder()
        {
            using (var t = new Transaction(this.Doc, "Create schema builder"))
            {
                t.Start();
                this.SchemaProp = this.SchemaBuilder.Finish();
                var entity = new Entity(this.SchemaProp);
                this.EntityProp = entity;
                t.Commit();
            }
        }

        public void CreateField(
            string fieldName,
            Type fieldType,
            string descriptionOfField,
            string schemaName,
            bool isSchemaBuilderFinish)
        {
            //если schema не создавалась с нуля, то улетаем. поле уже существует.
            if (this.SchemaBuilder == null)
            {
                CreateSchemaBuilder(schemaName, this.Doc);
            }
            using (var t = new Transaction(this.Doc, "Create field"))
            {
                t.Start();
                ////Проверяем есть ли уже такая схема с полем
                //var schema = GetSchemaByName(schemaName);
                //if (schema == null)
                //{
                //    MessageBox.Show("Схема Extensible Storage не найдена");
                //    return;
                //}
                //if (!schema.IsValidObject)
                //{
                //    MessageBox.Show("Схема Extensible Storage некорретная");
                //    return;
                //}
                //если поле уже содержится в схеме, то улетаем
                //var fieldNames = schema.ListFields().Select(f => f.FieldName);
                //if (fieldNames.Contains(fieldName))
                //    return;
                FieldBuilder fieldBuilder =
                    this.SchemaBuilder.AddSimpleField(fieldName, fieldType);
                /*fieldBuilder.SetUnitType(unitType);*/
                fieldBuilder.SetDocumentation(descriptionOfField);
                //var entity = new Entity(schema);
                //this.EntityProp = entity;
                t.Commit();
            }
            //и есл завершили создание полей, то завершаем создание схема билдер
            if (isSchemaBuilderFinish)
                FinishSchemaBuilder();
        }

        public void SetFieldValue<TFieldValue>(Element oElement, string fieldName, object valueToSet/*, DisplayUnitType displayUnitType*/)
        {
            using (var t = new Transaction(this.Doc, "Set field value"))
            {
                t.Start();
                var fieldSpliceLocation = this.SchemaProp.GetField(fieldName);
                // set the value for this entity
                this.EntityProp.Set(fieldSpliceLocation, (TFieldValue)valueToSet);
                oElement.SetEntity(this.EntityProp); // store the entity in the element
                t.Commit();
            }
        }

        public void SetFieldValue<TFieldValue>(Element oElement, string fieldName, object valueToSet, string schemaName/*, DisplayUnitType displayUnitType*/)
        {
            using (var t = new Transaction(oElement.Document, "Set field value"))
            {
                t.Start();
                var schema = GetSchemaByName(schemaName);
                var entity = new Entity(schema);
                var fieldSpliceLocation = schema.GetField(fieldName);
                // set the value for this entity
                entity.Set(fieldSpliceLocation, (TFieldValue)valueToSet);
                oElement.SetEntity(entity); // store the entity in the element
                t.Commit();
            }
        }

        public void SetFieldValue<TFieldValue>(List<Element> oElements, string fieldName, object valueToSet/*, DisplayUnitType displayUnitType*/)
        {
            using (var t = new Transaction(this.Doc, "Set field values"))
            {
                t.Start();
                var fieldSpliceLocation = this.SchemaProp.GetField(fieldName);
                // set the value for this entity
                this.EntityProp.Set(fieldSpliceLocation, (TFieldValue)valueToSet);
                foreach (var oElement in oElements)
                {
                    if (oElement == null)
                        continue;
                    oElement.SetEntity(this.EntityProp); // store the entity in the element
                }
                t.Commit();
            }
        }



        public object GetFieldValue<TFieldValue>(Element oElement, string fieldName, string schemaName/*, DisplayUnitType displayUnitType*/)
        {
            //Entity retrievedEntity = oElement.GetEntity(this.SchemaProp);
            //var retrievedData =
            //        retrievedEntity.Get<TFieldValue>(SchemaProp.GetField(fieldName)/*,
            //        displayUnitType*/);
            var schema = GetSchemaByName(schemaName);
            //если схемы не существует, то уходим
            if (schema == null)
                return null;
            var schemaEntity = oElement.GetEntity(schema);
            if (!schemaEntity.IsValid())
                return new object();
            var retrievedData = schemaEntity.Get<TFieldValue>(fieldName);
            return retrievedData;
        }

        public List<TElementType> GetElementsWithGuid<TElementType>(Document doc, Guid guid, string fieldName, string schemaName)
        {
            var elementsWithGuid = new FilteredElementCollector(doc)
                .OfClass(typeof(TElementType))
                .Where(e => this.GetFieldValue<Guid>(e, fieldName, schemaName).Equals(guid))
                .Cast<TElementType>()
                .ToList();
            return elementsWithGuid;
        }

        private Schema GetSchemaByName(string schemaName)
        {
            var schema = Schema.ListSchemas().FirstOrDefault(s => s.SchemaName.Equals(schemaName));
            return schema;
        }
    }
}
