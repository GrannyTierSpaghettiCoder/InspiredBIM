﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class RoomExts
    {
        public static XYZ GetCenterPoint(this Room room)
        {
            // Get the room center point.
            XYZ boundCenter = room.GetElementCenter();
            LocationPoint locPt = (LocationPoint)room.Location;
            XYZ roomCenter = new XYZ(boundCenter.X, boundCenter.Y, locPt.Point.Z);
            return roomCenter;
        }

        public static UV GetCenterPointUV(this Room room)
        {
            // Get the room center point.
            var centerPoint = room.GetCenterPoint();
            return new UV(centerPoint.X, centerPoint.Y);
        }
    }
}
