﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class DuctExts
    {
        public static List<Connector> GetConnectors(this Duct oDuct)
        {
            var csi = oDuct.ConnectorManager.Connectors.ForwardIterator();
            var connectors = new List<Connector>();

            while (csi.MoveNext())
            {
                var connector = csi.Current as Connector;
                connectors.Add(connector);
            }

            return connectors;
        }

        
        public static List<XYZ> GetStartAndEndPoint(this Duct oDuct)
        {
            //The wind pipe curve
            List<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = oDuct.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }

            return list;
        }
    }
}
