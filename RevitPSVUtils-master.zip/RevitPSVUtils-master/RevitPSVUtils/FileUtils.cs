﻿using RevitPSVUtils.EnumData;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WinDialogUtils;

namespace RevitPSVUtils
{
    public class FileRvtUtils
    {
        public static List<string> GetRevitProjectFilesFromFolder(
            Environment.SpecialFolder startupFolder, SearchEnum searchEnum)
        {
            var folderPath = FolderUtils.GetFolderPath(startupFolder);
            if (folderPath == string.Empty)
                return null;
            string[] rvtFilePathList = null;
            if (searchEnum == SearchEnum.CurrentFolder)
            {
                rvtFilePathList = Directory.GetFiles(folderPath, "*.rvt", SearchOption.TopDirectoryOnly);
            }
            else
            {
                rvtFilePathList = Directory.GetFiles(folderPath, "*.rvt", SearchOption.AllDirectories);
            }
            if (rvtFilePathList.Count() == 0)
                return null;
            var rvtFilesNonBackupList = rvtFilePathList.Where(f => !Regex.IsMatch(f, @"^*\.\d{4}\.rvt$")).ToList();

            return rvtFilesNonBackupList;
        }
    }
}
