﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RevitPSVUtils
{
    public static class ElementUtils
    {

        public static void SetParameterValueToElementList(
            ExternalCommandData commandData,
            List<Element> oElements,
            string parameterName,
            string stringValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                foreach (var elementItem in oElements)
                {
                    if (elementItem == null)
                        continue;

                    var parameter = elementItem.LookupParameter(parameterName);
                    if (parameter == null)
                        return;
                    if (parameter.IsReadOnly)
                        continue;

                    if (parameter.StorageType == StorageType.String)
                    {
                        parameter.Set(stringValue);
                    }
                }
                t.Commit();
            }
        }

        public static void SetElementParameterValue(ExternalCommandData commandData,
            Element oElement,
            string parameterName,
            string parameterValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        parameter.Set(parameterValue);
                        break;
                    }
                }
                t.Commit();
            }
        }

        public static void SetElementParameterValue(Element oElement,
            string parameterName,
            string parameterValue)
        {
            if (oElement == null)
                return;

            using (var t = new Autodesk.Revit.DB.Transaction(oElement.Document, "Set params"))
            {
                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        parameter.Set(parameterValue);
                        break;
                    }
                }
                t.Commit();
            }
        }

        public static void SetElementParameterValue(ExternalCommandData commandData,
            Element oElement,
            string parameterName,
            int parameterValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Autodesk.Revit.DB.Transaction(doc, "Set params"))
            {
                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        parameter.Set(parameterValue);
                        break;
                    }
                }
                t.Commit();
            }
        }

        public static void SetElementParameterValue(ExternalCommandData commandData,
           Element oElement,
           string parameterName,
           double parameterValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Transaction(doc, "Set params"))
            {
                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        parameter.Set(parameterValue);
                        break;
                    }
                }
                t.Commit();
            }
        }

        /// <summary>
        /// Метод устанавливает значения для параметра
        /// Если параметр имеет тип отличный от строкового, то значение автоматически берёт нужный тип данных
        /// </summary>
        /// <param name="commandData"></param>
        /// <param name="oElement"></param>
        /// <param name="parameterName"></param>
        /// <param name="parameterValue"></param>
        public static void SetElementParameterValueWithParsing(ExternalCommandData commandData,
           Element oElement,
           string parameterName,
           string parameterValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;
            using (var t = new Transaction(doc, "Set params"))
            {
                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        if (parameter.StorageType == StorageType.String)
                        {
                            parameter.Set(parameterValue);
                        }
                        else if (parameter.StorageType == StorageType.Double)
                        {
                            var parameterValueDouble = NumberUtils.ParseStringToDouble(parameterValue);
                            parameter.Set(parameterValueDouble);
                        }
                        else if (parameter.StorageType == StorageType.Integer)
                        {
                            var parameterValueInt = NumberUtils.ParseStringToInt(parameterValue);
                            parameter.Set(parameterValueInt);
                        }
                        break;
                    }
                }
                t.Commit();
            }
        }

        /// <summary>
        /// Выбираем из нескольких типов данных тот, который подходит под целевой параметр
        /// </summary>
        /// <param name="commandData"></param>
        /// <param name="oElement"></param>
        /// <param name="parameterName"></param>
        /// <param name="stringValue"></param>
        /// <param name="intValue"></param>
        /// <param name="doubleValue"></param>
        public static void SetElementParameterValue(ExternalCommandData commandData,
           Element oElement,
           string parameterName,
           string stringValue,
           int intValue,
           double doubleValue)
        {


            if (oElement == null)
                return;

            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            if (WorksharingUtils.GetCheckoutStatus(doc, oElement.Id) == CheckoutStatus.OwnedByOtherUser)
                return;

            using (var t = new Transaction(doc, "Set params"))
            {


                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.IsReadOnly)
                        continue;
                    if (parameter.Definition == null)
                        continue;
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        if (parameter.StorageType == StorageType.String)
                        {
                            parameter.Set(stringValue);
                        }
                        else if (parameter.StorageType == StorageType.Double)
                        {
                            parameter.Set(doubleValue);
                        }
                        else if (parameter.StorageType == StorageType.Integer)
                        {
                            parameter.Set(intValue);
                        }
                        break;
                    }
                }
                t.Commit();
            }
        }

        public static void SetElementParameterValue(ExternalCommandData commandData,
          Element oElement,
          string parameterName,
          string stringValue,
          int intValue,
          double doubleValue,
          ElementId oElementId)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var worksetTable = doc.GetWorksetTable();
            var workset = worksetTable.GetWorkset(oElement.WorksetId);

            if (!workset.Owner.Equals(doc.Application.Username))
                return;


            using (var t = new Transaction(doc, "Set params"))
            {


                t.Start();
                foreach (Parameter parameter in oElement.Parameters)
                {
                    if (parameter.IsReadOnly)
                        continue;
                    if (parameter.Definition.Name.Equals(parameterName))
                    {
                        if (parameter.StorageType == StorageType.String)
                        {
                            parameter.Set(stringValue);
                        }
                        else if (parameter.StorageType == StorageType.Double)
                        {
                            parameter.Set(doubleValue);
                        }
                        else if (parameter.StorageType == StorageType.Integer)
                        {
                            parameter.Set(intValue);
                        }
                        else if (parameter.StorageType == StorageType.ElementId)
                        {
                            parameter.Set(oElementId);
                        }
                        break;
                    }
                }
                t.Commit();
            }
        }


        public static void GetEdgePointsAlignedToView(
            Element oElement,
            Document doc,
            ref XYZ maxPoint,
            ref XYZ minPoint)
        {
            BoundingBoxXYZ viewBB = doc.ActiveView.get_BoundingBox(doc.ActiveView);

            BoundingBoxXYZ elemBB = oElement.get_BoundingBox(doc.ActiveView);
            minPoint = viewBB.Transform.Inverse.OfPoint(elemBB.Min);
            maxPoint = viewBB.Transform.Inverse.OfPoint(elemBB.Max);
        }

        public static List<Element> GetElementsOfBuiltInCategory(
            ExternalCommandData commandData,
            BuiltInCategory builtInCategory)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            //get instances of category
            var fInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .OfCategory(builtInCategory)
                .Cast<Element>()
                .ToList();
            return fInstances;
        }



        public static List<Element> GetAllTheElements(
            ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            //get instances of category
            var fInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .Cast<Element>()
                .ToList();
            return fInstances;
        }

        public static ICollection<ElementId> GetAllTheElementsAsElementIds(
            ExternalCommandData commandData)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            //get instances of category
            var elementIdList = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .ToElementIds();
            return elementIdList;
        }


        public static List<Element> GetElementsOfBuiltInCategoryList(
            ExternalCommandData commandData,
            List<BuiltInCategory> builtInCategoryList)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            var multiFilter = new ElementMulticategoryFilter(builtInCategoryList);
            var fInstances = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .WherePasses(multiFilter)
                .Cast<Element>()
                .ToList();
            return fInstances;
        }



        public static List<Element> GetModelElements(
                                        Document doc)
        {

            var elements
                    = new FilteredElementCollector(doc)
                            .WhereElementIsNotElementType()
                            .Cast<Element>()
                            .ToList();
            return elements;
        }


    }
}
