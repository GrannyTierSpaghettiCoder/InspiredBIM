﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils.EnumData
{
    public enum ExtStorageEnum
    {
        Int,
        Short,
        Byte,
        Double,
        Float,
        Bool,
        String,
        GUID,
        ElementId,
        XYZ,
        UV
    }
}
