﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public class TextNoteUtils
    {
        public static TextNote CreateTextNoteOnView(ExternalCommandData commandData, View view, string textValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var origin = XYZ.Zero;
            var defaultTypeId = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType);

            var note = TextNote.Create(doc, view.Id, origin, textValue, defaultTypeId);
            return note;
        }

        public static TextNote CreateTextNoteOnView(ExternalCommandData commandData, View view,
                                                    XYZ insertPoint, string textValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var defaultTypeId = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType);

            var note = TextNote.Create(doc, view.Id, insertPoint, textValue, defaultTypeId);
            return note;
        }

        public static TextNote CreateTextNoteOnViewRelativeToTopRightSideViewPort(ExternalCommandData commandData,
                                                    View viewToInsertText,
                                                    Viewport viewPort,
                                                    double xOffsetFromRightTop,
                                                    double yOffsetFromRightTop,
                                                    string textValue)
        {
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var defaultTypeId = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType);

            var sheetBox = viewPort.GetBoxOutline();
            var max = viewPort.GetBoxOutline().MaximumPoint;

            var insertPoint = new XYZ(max.X + xOffsetFromRightTop, max.Y + yOffsetFromRightTop, 0);

            var note = TextNote.Create(doc, viewToInsertText.Id, insertPoint, textValue, defaultTypeId);
            return note;
        }
    }
}
