﻿using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class RibbonPanelExts
    {
        public static PushButton AddButton(
            this RibbonPanel panel,
            string buttonName,
            string dllFullPath,
            string dllClassName)
        {
            var newButton = panel.AddItem(
                        new PushButtonData(
                            buttonName,
                            buttonName,
                            dllFullPath,
                            dllClassName))
                                as PushButton;
            return newButton;
        }
    }
}
