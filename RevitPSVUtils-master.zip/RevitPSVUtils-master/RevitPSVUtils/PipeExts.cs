﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitPSVUtils
{
    public static class PipeExts
    {

        public static List<Connector> GetConnectors(this Pipe oPipe)
        {
            var csi = oPipe.ConnectorManager.Connectors.ForwardIterator();
            var connectors = new List<Connector>();
            while (csi.MoveNext())
            {
                var connector = csi.Current as Connector;
                connectors.Add(connector);
            }

            return connectors;
        }

        public static List<XYZ> GetStartEndPoints(this Pipe oPipe)
        {
            //The wind pipe curve
            IList<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = oPipe.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }
            var points = new List<XYZ> { list.ElementAt(0), list.ElementAt(1) };
            return points;
        }

        public static Curve GetPipeCurve(this Pipe oPipe)
        {
            //The wind pipe curve
            IList<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = oPipe.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }
            Curve curve = Line.CreateBound(list.ElementAt(0), list.ElementAt(1)) as Curve;
            curve.MakeUnbound();
            return curve;
        }

        public static List<XYZ> GetStartAndEndPoint(this Pipe oPipe)
        {
            //The wind pipe curve
            List<XYZ> list = new List<XYZ>();
            ConnectorSetIterator csi = oPipe.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                list.Add(conn.Origin);
            }

            return list;
        }

        public static List<XYZ> GetStartAndEndPointWithProjectPoint(this Pipe oPipe, ExternalCommandData commandData)
        {

            //The wind pipe curve
            List<XYZ> connectorPointList = new List<XYZ>();
            ConnectorSetIterator csi = oPipe.ConnectorManager.Connectors.ForwardIterator();
            while (csi.MoveNext())
            {
                Connector conn = csi.Current as Connector;
                connectorPointList.Add(conn.Origin);
            }

            var connectorPointWithProjectPoint = new List<XYZ>();

            foreach (var connectorPoint in connectorPointList)
            {
                var convertedPoint = TopoUtils.ConvertPointRelativeToSurveyPosition(commandData, connectorPoint);
                connectorPointWithProjectPoint.Add(convertedPoint);
            }

            return connectorPointWithProjectPoint;
        }

        public static double GetOuterDiameter(this Pipe oPipe)
        {
            var outerDiameter = oPipe.get_Parameter(BuiltInParameter.RBS_PIPE_OUTER_DIAMETER).AsDouble();
            return NumberUtils.FeetToMillimeters(outerDiameter);
        }

        public static double GetOuterDiameterWithInsulation(this Pipe oPipe)
        {
            var outerDiameter = oPipe.get_Parameter(BuiltInParameter.RBS_PIPE_OUTER_DIAMETER).AsDouble();
            var insulationThickness = oPipe.get_Parameter(BuiltInParameter.RBS_REFERENCE_INSULATION_THICKNESS).AsDouble();
            var outerDiamWithInsulation = outerDiameter + 2 * insulationThickness;
            return NumberUtils.FeetToMillimeters(outerDiamWithInsulation);
        }

        public static double GetLength(this Pipe oPipe)
        {
            var length = oPipe.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH).AsDouble();
            return NumberUtils.FeetToMillimeters(length);
        }
    }
}
